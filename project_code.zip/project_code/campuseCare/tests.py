import uuid
from datetime import date, time, timedelta
from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.db import IntegrityError
from django.urls import reverse

from .models import (
    Student, Staff, Appointment, WaitlistEntry,
    ExternalReferral, HealthAnomalyAlert, Notification,
    HealthAlert, StudentHealthAlertRead
)
from .triage_engine import evaluate_triage, trigger_emergency_clinical_alert
from .waitlist_service import handle_slot_cancellation_and_waitlist
from .reminder_engine import process_all_reminders
from .anomaly_detector import run_health_anomaly_detection
from .pdf_generator import generate_clinic_management_pdf


class CampusCareSystemIntegrationTests(TestCase):
    def setUp(self):
        self.client = Client()

        # Create Students
        self.user1 = User.objects.create_user(username='student1', password='password123', first_name='John', last_name='Doe', email='john@spu.ac.za')
        self.student1 = Student.objects.create(
            user=self.user1, student_number='SPU202601', faculty='Science', year_of_study=2, blood_type='O+'
        )

        self.user2 = User.objects.create_user(username='student2', password='password123', first_name='Jane', last_name='Smith', email='jane@spu.ac.za')
        self.student2 = Student.objects.create(
            user=self.user2, student_number='SPU202602', faculty='Humanities', year_of_study=3, blood_type='A+'
        )

        # Create Clinical Staff
        self.staff_user = User.objects.create_user(username='dr_sarah', password='password123', first_name='Sarah', last_name='Connor', is_staff=True)
        self.staff = Staff.objects.create(user=self.staff_user, staff_id='STF001', role='doctor')

        # Create Non-clinical Staff
        self.admin_user = User.objects.create_user(username='clerk1', password='password123', first_name='Clerk', last_name='Desk')
        self.non_clinical_staff = Staff.objects.create(user=self.admin_user, staff_id='STF099', role='other')

    # ==========================================================================
    # 1. Anti-Double-Booking & Concurrency Tests
    # ==========================================================================
    def test_prevent_double_booking_database_constraint(self):
        """Strictly prevents double-booking of the same slot using database-level constraints."""
        booking_date = date.today() + timedelta(days=2)
        booking_time = time(9, 0)

        # First booking succeeds
        Appointment.objects.create(
            student=self.student1,
            assigned_staff=self.staff,
            category='general',
            urgency='routine',
            appointment_date=booking_date,
            appointment_time=booking_time,
            symptoms='General checkup',
            status='confirmed'
        )

        # Second booking for the exact same staff and slot MUST raise database IntegrityError
        with self.assertRaises(IntegrityError):
            Appointment.objects.create(
                student=self.student2,
                assigned_staff=self.staff,
                category='general',
                urgency='routine',
                appointment_date=booking_date,
                appointment_time=booking_time,
                symptoms='Cold symptoms',
                status='confirmed'
            )

    # ==========================================================================
    # 2. Digital Intake Form & Triage Engine Tests
    # ==========================================================================
    def test_triage_engine_classifications(self):
        """Verifies clinical triage properly classifies Emergency, Urgent, and Routine cases."""
        # Emergency: Red flag chest pain
        res_emerg = evaluate_triage(
            category='general',
            symptoms_text='Sudden sharp crushing pain',
            red_flags=['chest_pain']
        )
        self.assertEqual(res_emerg['priority'], 'emergency')
        self.assertTrue(res_emerg['is_emergency'])

        # Emergency: Suicidal thoughts keyword
        res_suicide = evaluate_triage(
            category='mental',
            symptoms_text='I feel completely hopeless and have suicidal thoughts',
            red_flags=[]
        )
        self.assertEqual(res_suicide['priority'], 'emergency')

        # Urgent: Severe pain score 8/10
        res_urgent_pain = evaluate_triage(
            category='injury',
            symptoms_text='Sprained wrist after falling down stairs',
            pain_scale=8
        )
        self.assertEqual(res_urgent_pain['priority'], 'urgent')

        # Urgent: Sexual health PEP 72h window
        res_pep = evaluate_triage(
            category='sexual',
            symptoms_text='Need post-exposure prophylaxis advice',
            red_flags=['sexual_pep_72h']
        )
        self.assertEqual(res_pep['priority'], 'urgent')

        # Routine: Mild symptoms
        res_routine = evaluate_triage(
            category='general',
            symptoms_text='Routine medical certificate renewal',
            pain_scale=0
        )
        self.assertEqual(res_routine['priority'], 'routine')

    def test_emergency_alert_triggers_clinical_staff_notifications(self):
        """Verifies Emergency classification triggers immediate real-time staff alerts."""
        appt = Appointment.objects.create(
            student=self.student1,
            assigned_staff=self.staff,
            category='general',
            urgency='emergency',
            appointment_date=date.today(),
            appointment_time=time(10, 0),
            symptoms='Severe breathing difficulty and chest pain',
            status='confirmed'
        )

        initial_notifs = Notification.objects.filter(user=self.staff.user).count()
        trigger_emergency_clinical_alert(appt)
        new_notifs = Notification.objects.filter(user=self.staff.user).count()

        self.assertGreater(new_notifs, initial_notifs)
        latest_notif = Notification.objects.filter(user=self.staff.user).latest('created_at')
        self.assertIn("EMERGENCY CLINICAL ALERT", latest_notif.title)

    # ==========================================================================
    # 3. Priority-First Queue Ordering Tests
    # ==========================================================================
    def test_queue_ordering_prioritizes_emergency_and_urgent_over_routine(self):
        """Urgent cases must be placed ahead of Routine cases regardless of booking order, Emergency first."""
        today = date.today()

        # Routine booked at 08:00
        appt_routine = Appointment.objects.create(
            student=self.student1,
            assigned_staff=self.staff,
            category='general',
            urgency='routine',
            appointment_date=today,
            appointment_time=time(8, 0),
            symptoms='Routine rash checkup',
            status='confirmed'
        )

        # Urgent booked later at 11:00
        appt_urgent = Appointment.objects.create(
            student=self.student2,
            assigned_staff=self.staff,
            category='injury',
            urgency='urgent',
            appointment_date=today,
            appointment_time=time(11, 0),
            symptoms='Suspected ankle fracture',
            status='confirmed'
        )

        # Emergency booked at 14:00
        appt_emergency = Appointment.objects.create(
            student=None,
            assigned_staff=self.staff,
            category='mental',
            urgency='emergency',
            appointment_date=today,
            appointment_time=time(14, 0),
            symptoms='Acute psychological crisis',
            status='confirmed'
        )

        # Query ordered by priority then time (matching staff_dashboard)
        ordered_appts = Appointment.objects.filter(appointment_date=today).exclude(status='cancelled')
        sorted_appts = sorted(ordered_appts, key=lambda a: (a.priority_sort_key, a.appointment_time))

        self.assertEqual(sorted_appts[0].pk, appt_emergency.pk)
        self.assertEqual(sorted_appts[1].pk, appt_urgent.pk)
        self.assertEqual(sorted_appts[2].pk, appt_routine.pk)

    # ==========================================================================
    # 4. Actionable Reminders via Direct Tokens Tests
    # ==========================================================================
    def test_reminder_one_click_actions_without_login(self):
        """Reminder direct action token allows confirming or cancelling without prior login."""
        appt = Appointment.objects.create(
            student=self.student1,
            assigned_staff=self.staff,
            category='general',
            urgency='routine',
            appointment_date=date.today() + timedelta(days=1),
            appointment_time=time(14, 0),
            symptoms='Cold follow-up',
            status='pending'
        )

        # One-click Confirm via direct token URL
        url_confirm = reverse('appointment_action_view', kwargs={'token': appt.action_token}) + '?action=confirm'
        response = self.client.get(url_confirm)
        self.assertEqual(response.status_code, 200)
        appt.refresh_from_db()
        self.assertEqual(appt.status, 'confirmed')

        # One-click Cancel via direct token URL
        url_cancel = reverse('appointment_action_view', kwargs={'token': appt.action_token}) + '?action=cancel'
        response = self.client.get(url_cancel)
        self.assertEqual(response.status_code, 200)
        appt.refresh_from_db()
        self.assertEqual(appt.status, 'cancelled')

    # ==========================================================================
    # 5. Cancellation & Strict Priority Waitlist Reassignment Tests
    # ==========================================================================
    def test_slot_cancellation_reallocates_to_highest_priority_waitlist(self):
        """Cancelling a slot automatically offers it to waitlisted students in strict priority order (Urgent > Routine)."""
        slot_date = date.today() + timedelta(days=3)
        slot_time = time(10, 0)

        # Existing confirmed booking
        booked_appt = Appointment.objects.create(
            student=self.student1,
            assigned_staff=self.staff,
            category='general',
            urgency='routine',
            appointment_date=slot_date,
            appointment_time=slot_time,
            symptoms='Annual health screening',
            status='confirmed'
        )

        # Waitlist 1: Routine (created first)
        wl_routine = WaitlistEntry.objects.create(
            student=self.student1,
            preferred_staff=self.staff,
            preferred_date=slot_date,
            category='general',
            urgency='routine',
            symptoms='Routine checkup',
            status='waiting'
        )

        # Waitlist 2: Urgent (created second, but higher priority)
        wl_urgent = WaitlistEntry.objects.create(
            student=self.student2,
            preferred_staff=self.staff,
            preferred_date=slot_date,
            category='injury',
            urgency='urgent',
            symptoms='Severe acute back spasm',
            status='waiting'
        )

        # Cancel the appointment and trigger waitlist reallocation
        booked_appt.status = 'cancelled'
        booked_appt.save()
        reallocated = handle_slot_cancellation_and_waitlist(booked_appt)

        self.assertIsNotNone(reallocated)
        # Assert the urgent student was chosen ahead of routine despite booking later
        self.assertEqual(reallocated.student, self.student2)
        self.assertEqual(reallocated.urgency, 'urgent')
        wl_urgent.refresh_from_db()
        self.assertEqual(wl_urgent.status, 'booked')

    # ==========================================================================
    # 6. Fully Anonymized Consultations Tests (Structural Disassociation)
    # ==========================================================================
    def test_anonymous_booking_structural_disassociation(self):
        """Anonymous booking must permanently disassociate from any student ID (student is None, zero PII)."""
        self.client.login(username='student1', password='password123')

        booking_date = (date.today() + timedelta(days=4)).isoformat()
        response = self.client.post(reverse('book_appointment'), {
            'staff_id': self.staff.pk,
            'appointment_date': booking_date,
            'appointment_time': '15:00',
            'category': 'mental',
            'symptoms': 'Experiencing severe academic burnout and chronic insomnia',
            'intake_duration': '1-3 days',
            'intake_pain_scale': 4,
            'is_anonymous': '1'
        })

        # Find the anonymous appointment
        anon_appt = Appointment.objects.filter(category='mental', is_anonymous=True).latest('created_at')

        # Assert zero PII / structural disassociation:
        self.assertIsNone(anon_appt.student)
        self.assertTrue(anon_appt.is_anonymous)
        self.assertTrue(anon_appt.anonymous_code.startswith('ANON-ME-'))
        self.assertIsNotNone(anon_appt.anonymous_token)

    def test_anonymous_booking_restricted_to_mental_and_sexual_health(self):
        """Anonymous booking is rejected if attempted on general or injury consultations."""
        self.client.login(username='student1', password='password123')

        response = self.client.post(reverse('book_appointment'), {
            'staff_id': self.staff.pk,
            'appointment_date': (date.today() + timedelta(days=5)).isoformat(),
            'appointment_time': '11:00',
            'category': 'injury',  # Disallowed for anonymous
            'symptoms': 'Sprained wrist',
            'is_anonymous': '1'
        }, follow=True)

        self.assertContains(response, 'Anonymous booking is strictly reserved for Mental Health')

    # ==========================================================================
    # 7. Role-Based Access Control (RBAC) Tests
    # ==========================================================================
    def test_clinical_records_rbac_enforcement(self):
        """Unauthorized non-clinical users cannot access confidential patient medical records."""
        # Non-clinical staff login
        self.client.login(username='clerk1', password='password123')
        resp = self.client.get(reverse('staff_view_records'))
        self.assertEqual(resp.status_code, 403)

        # Student login
        self.client.login(username='student1', password='password123')
        resp = self.client.get(reverse('staff_view_records'))
        self.assertEqual(resp.status_code, 403)

        # Authorized clinical staff login
        self.client.login(username='dr_sarah', password='password123')
        resp = self.client.get(reverse('staff_view_records'))
        self.assertEqual(resp.status_code, 200)

    # ==========================================================================
    # 8. Epidemiological Trend Anomaly Detection Tests
    # ==========================================================================
    def test_health_trend_anomaly_detection_spike(self):
        """Detects sudden volume spikes and triggers alerts to designated clinic management."""
        today = date.today()

        # Inject sudden spike in mental health consultations over past 7 days
        for i in range(6):
            Appointment.objects.create(
                student=self.student1,
                assigned_staff=self.staff,
                category='mental',
                urgency='urgent',
                appointment_date=today - timedelta(days=i),
                appointment_time=time(9, 0),
                symptoms=f'Acute mental health spike case {i}',
                status='confirmed'
            )

        alerts = run_health_anomaly_detection(reference_date=today)
        self.assertGreater(len(alerts), 0)
        mental_alert = next((a for a in alerts if 'mental' in a.metric_name), None)
        self.assertIsNotNone(mental_alert)
        self.assertGreaterEqual(mental_alert.percent_increase, 50.0)

    # ==========================================================================
    # 9. Automated PDF Report Generation Tests
    # ==========================================================================
    def test_management_pdf_report_generation(self):
        """Verifies valid binary PDF report generation using ReportLab."""
        metrics = {
            'total_appointments': 45,
            'completed_count': 38,
            'no_show_count': 4,
            'no_show_rate': 8.9,
            'cancelled_count': 3,
            'avg_wait_minutes': 11.4,
            'acute_cases_count': 9,
            'referrals_count': 5,
            'category_distribution': [
                {'category': 'Mental Health', 'total': 20, 'pct': 44.4, 'completed': 18, 'urgent_count': 6},
                {'category': 'General Health', 'total': 25, 'pct': 55.6, 'completed': 20, 'urgent_count': 3},
            ],
            'demographics': [
                {'name': 'Faculty of Science', 'count': 25, 'pct': 55.6},
                {'name': 'Faculty of Humanities', 'count': 20, 'pct': 44.4}
            ]
        }

        pdf_stream = generate_clinic_management_pdf(
            "Weekly Test Report",
            date.today() - timedelta(days=7),
            date.today(),
            metrics,
            "Quality Assurance System"
        )

        pdf_bytes = pdf_stream.getvalue()
        self.assertGreater(len(pdf_bytes), 500)
        # PDF files strictly start with the magic header %PDF
        self.assertTrue(pdf_bytes.startswith(b'%PDF'))

    # ==========================================================================
    # 8. Student Health Alerts, Live Weather & Read-Receipt Tests
    # ==========================================================================
    def test_health_alerts_page_authenticated_student(self):
        """Ensures students can view the Health Alerts hub with live weather and news."""
        self.client.login(username='student1', password='password123')
        alert = HealthAlert.objects.create(
            title='Severe Kimberley Heat Advisory',
            message='Extreme ambient temperatures recorded. Hydrate regularly.',
            severity='warning',
            category='weather',
            source='Campus Meteorology'
        )
        response = self.client.get(reverse('health_alerts'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Severe Kimberley Heat Advisory')
        self.assertContains(response, 'Campus Health Radar & Alerts')
        self.assertIn('weather', response.context)
        self.assertIn('news', response.context)
        self.assertIn('alerts', response.context)

    def test_health_alert_read_tracking_and_badge_decrement(self):
        """Verifies that marking an alert read decrements the unread count from 1 to 0."""
        self.client.login(username='student1', password='password123')
        alert = HealthAlert.objects.create(
            title='Campus Respiratory Allergy Warning',
            message='Elevated particulate count. Asthma sufferers carry rescue inhalers.',
            severity='info',
            category='air_quality'
        )

        # Before marking read, student dashboard has active alert in context and unread count >= 1
        dash_res = self.client.get(reverse('student_dashboard'))
        self.assertEqual(dash_res.status_code, 200)
        self.assertGreaterEqual(dash_res.context['alert_unread_count'], 1)

        # Mark alert as read
        action_res = self.client.post(reverse('health_alert_action'), {
            'action': 'mark_read',
            'alert_id': alert.pk,
            'ajax': 'true'
        })
        self.assertEqual(action_res.status_code, 200)
        self.assertTrue(StudentHealthAlertRead.objects.filter(user=self.user1, alert=alert).exists())

        # Unread count now reflects read status
        dash_res2 = self.client.get(reverse('student_dashboard'))
        self.assertFalse(any(a.pk == alert.pk for a in dash_res2.context['unseen_alerts']))

    def test_health_alert_mark_all_read(self):
        """Verifies bulk marking all health alerts as read."""
        self.client.login(username='student1', password='password123')
        HealthAlert.objects.all().delete()
        a1 = HealthAlert.objects.create(title='Alert 1', message='Notice 1', severity='info')
        a2 = HealthAlert.objects.create(title='Alert 2', message='Notice 2', severity='danger')

        action_res = self.client.post(reverse('health_alert_action'), {
            'action': 'mark_all_read'
        })
        self.assertEqual(StudentHealthAlertRead.objects.filter(user=self.user1).count(), 2)

    def test_sms_gateway_confirmations_cancellations_and_saved_phone(self):
        """
        Validates BulkSMS integration:
        1. Number normalization (local South African 071... -> +2771...)
        2. Student phone save triggers registration SMS
        3. Booking confirmation SMS dispatch
        4. Staff approval SMS dispatch
        5. Student cancellation SMS dispatch
        6. Diagnostic SMS test endpoint
        7. Audit logs created in SMSLog
        """
        from campuseCare.sms_service import normalize_phone_number, send_sms
        from campuseCare.models import SMSLog

        # 1. Normalization
        self.assertEqual(normalize_phone_number('0715441437'), '+27715441437')
        self.assertEqual(normalize_phone_number('082 123 4567'), '+27821234567')
        self.assertEqual(normalize_phone_number('+27715441437'), '+27715441437')
        self.assertEqual(normalize_phone_number('27715441437'), '+27715441437')

        # 2. Saving phone number on student auto-normalizes
        SMSLog.objects.all().delete()
        self.student1.phone = '0829998877'
        self.student1.save()
        self.assertEqual(self.student1.phone, '+27829998877')

        # 3. Test booking confirmation dispatches SMS
        self.client.login(username='student1', password='password123')
        target_date = (date.today() + timedelta(days=2))
        book_res = self.client.post(reverse('book_appointment'), {
            'staff_id': self.staff.pk,
            'appointment_date': target_date.strftime('%Y-%m-%d'),
            'appointment_time': '10:00',
            'category': 'general',
            'symptoms': 'Routine general checkup',
            'intake_duration': '<24h',
            'intake_pain_scale': '0'
        })
        self.assertEqual(book_res.status_code, 302)
        appt = Appointment.objects.filter(student=self.student1, appointment_date=target_date).first()
        self.assertIsNotNone(appt)
        # Check confirmation SMS logged
        conf_sms = SMSLog.objects.filter(recipient_phone='+27829998877', message_type='confirmation').first()
        self.assertIsNotNone(conf_sms)
        self.assertIn('Confirmed General Consultation', conf_sms.message)

        # 4. Student cancellation dispatches cancellation SMS
        cancel_res = self.client.post(reverse('cancel_appointment', kwargs={'pk': appt.pk}))
        self.assertEqual(cancel_res.status_code, 302)
        appt.refresh_from_db()
        self.assertEqual(appt.status, 'cancelled')
        cancel_sms = SMSLog.objects.filter(recipient_phone='+27829998877', message_type='cancellation').first()
        self.assertIsNotNone(cancel_sms)
        self.assertIn('cancelled successfully', cancel_sms.message)

        # 5. Diagnostic SMS test endpoint
        self.client.login(username='dr_sarah', password='password123')
        test_api_res = self.client.post(reverse('test_send_sms_api'), {
            'phone': '0720001122',
            'message': 'Testing BulkSMS'
        })
        self.assertEqual(test_api_res.status_code, 200)
        self.assertTrue(test_api_res.json()['success'])
        self.assertTrue(SMSLog.objects.filter(recipient_phone='+27720001122', message_type='test').exists())


