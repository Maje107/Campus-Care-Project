from .models import Notification, HealthAlert, StudentHealthAlertRead, EmergencyAnnouncement


def global_alerts_and_notifications(request):
    """
    Context processor providing real-time unread notifications and health alerts
    data, lists, and counts across all templates for both Student and Staff users.
    """
    if not request.user.is_authenticated:
        return {
            'unread_count': 0,
            'alert_unread_count': 0,
            'unseen_health_alerts': [],
            'recent_notifications': [],
            'recent_health_alerts': [],
            'global_active_emergencies': [],
        }

    # 1. User Notifications
    notifs_qs = Notification.objects.filter(user=request.user).order_by('-created_at')
    unread_count = notifs_qs.filter(is_read=False).count()
    recent_notifications = list(notifs_qs[:8])

    # 2. Health Alerts & Read Status
    active_alerts = list(HealthAlert.objects.filter(is_active=True).order_by('-created_at')[:8])
    read_alert_ids = set(StudentHealthAlertRead.objects.filter(user=request.user).values_list('alert_id', flat=True))
    for a in active_alerts:
        a.is_read = (a.id in read_alert_ids)

    unseen_alerts = [a for a in active_alerts if not a.is_read]
    alert_unread_count = len(unseen_alerts)

    # 3. Emergency Announcements from clinical staff
    active_emergencies = list(
        EmergencyAnnouncement.objects.filter(is_active=True).select_related('staff__user').order_by('-created_at')[:3]
    )

    return {
        'unread_count': unread_count,
        'alert_unread_count': alert_unread_count,
        'unseen_health_alerts': unseen_alerts[:2],
        'recent_notifications': recent_notifications,
        'recent_health_alerts': active_alerts,
        'global_active_emergencies': active_emergencies,
    }
