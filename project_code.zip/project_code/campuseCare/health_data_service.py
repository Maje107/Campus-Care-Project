import json
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime
from django.utils import timezone
from .models import HealthAlert

# Kimberley / Sol Plaatje University coordinates
LATITUDE = -28.738
LONGITUDE = 24.764

# Simple in-memory cache with expiration
_CACHE = {
    'weather': None,
    'weather_ts': 0,
    'news': None,
    'news_ts': 0,
}

CACHE_TTL_WEATHER = 900  # 15 minutes
CACHE_TTL_NEWS = 1800     # 30 minutes

WMO_WEATHER_CODES = {
    0: ('Clear sky', 'fa-sun', 'text-warning'),
    1: ('Mainly clear', 'fa-cloud-sun', 'text-warning'),
    2: ('Partly cloudy', 'fa-cloud-sun', 'text-secondary'),
    3: ('Overcast', 'fa-cloud', 'text-secondary'),
    45: ('Foggy', 'fa-smog', 'text-muted'),
    48: ('Depositing rime fog', 'fa-smog', 'text-muted'),
    51: ('Light drizzle', 'fa-cloud-rain', 'text-info'),
    53: ('Moderate drizzle', 'fa-cloud-rain', 'text-info'),
    55: ('Dense drizzle', 'fa-cloud-rain', 'text-primary'),
    61: ('Slight rain', 'fa-cloud-showers-heavy', 'text-info'),
    63: ('Moderate rain', 'fa-cloud-showers-heavy', 'text-primary'),
    65: ('Heavy rain', 'fa-cloud-showers-heavy', 'text-primary'),
    80: ('Rain showers', 'fa-cloud-sun-rain', 'text-info'),
    81: ('Moderate showers', 'fa-cloud-sun-rain', 'text-primary'),
    82: ('Violent showers', 'fa-cloud-showers-heavy', 'text-danger'),
    95: ('Thunderstorm', 'fa-bolt', 'text-warning'),
    96: ('Thunderstorm with slight hail', 'fa-cloud-bolt', 'text-danger'),
    99: ('Thunderstorm with heavy hail', 'fa-cloud-bolt', 'text-danger'),
}


def get_weather_condition_display(code):
    return WMO_WEATHER_CODES.get(code, ('Variable Conditions', 'fa-cloud', 'text-secondary'))


def fetch_kimberley_weather():
    """
    Fetches real-time weather and air quality for Kimberley / Sol Plaatje University
    via Open-Meteo APIs. Uses caching for optimal performance.
    """
    now = time.time()
    if _CACHE['weather'] and (now - _CACHE['weather_ts'] < CACHE_TTL_WEATHER):
        return _CACHE['weather']

    weather_data = {
        'location': 'Sol Plaatje University, Kimberley',
        'province': 'Northern Cape, South Africa',
        'temperature': 25.0,
        'apparent_temperature': 25.0,
        'humidity': 38,
        'wind_speed': 12.0,
        'uv_index': 7.0,
        'uv_level': 'High',
        'uv_color': 'warning',
        'weather_code': 0,
        'weather_description': 'Sunny & Clear',
        'weather_icon': 'fa-sun',
        'weather_icon_color': 'text-warning',
        'aqi': 42,
        'aqi_level': 'Good',
        'aqi_color': 'success',
        'pm2_5': 9.5,
        'pm10': 18.0,
        'health_advisories': [],
        'updated_at': timezone.now().strftime('%H:%M'),
        'is_live': False,
    }

    # 1. Fetch live Open-Meteo Weather
    try:
        weather_url = (
            f"https://api.open-meteo.com/v1/forecast?latitude={LATITUDE}&longitude={LONGITUDE}"
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,uv_index"
            "&timezone=Africa%2FJohannesburg"
        )
        req = urllib.request.Request(weather_url, headers={'User-Agent': 'CampusCare-Weather/1.0'})
        with urllib.request.urlopen(req, timeout=4) as response:
            if response.status == 200:
                raw = json.loads(response.read().decode('utf-8'))
                current = raw.get('current', {})
                weather_data['temperature'] = round(float(current.get('temperature_2m', 25.0)), 1)
                weather_data['apparent_temperature'] = round(float(current.get('apparent_temperature', 25.0)), 1)
                weather_data['humidity'] = int(current.get('relative_humidity_2m', 38))
                weather_data['wind_speed'] = round(float(current.get('wind_speed_10m', 12.0)), 1)
                weather_data['uv_index'] = round(float(current.get('uv_index', 6.0)), 1)
                code = int(current.get('weather_code', 0))
                weather_data['weather_code'] = code
                desc, icon, color = get_weather_condition_display(code)
                weather_data['weather_description'] = desc
                weather_data['weather_icon'] = icon
                weather_data['weather_icon_color'] = color
                weather_data['is_live'] = True
    except Exception:
        # Graceful fallback to default values
        pass

    # 2. Fetch live Open-Meteo Air Quality
    try:
        aqi_url = (
            f"https://air-quality-api.open-meteo.com/v1/air-quality?latitude={LATITUDE}&longitude={LONGITUDE}"
            "&current=us_aqi,pm10,pm2_5,ozone&timezone=Africa%2FJohannesburg"
        )
        req = urllib.request.Request(aqi_url, headers={'User-Agent': 'CampusCare-AirQuality/1.0'})
        with urllib.request.urlopen(req, timeout=4) as response:
            if response.status == 200:
                raw = json.loads(response.read().decode('utf-8'))
                current = raw.get('current', {})
                weather_data['aqi'] = int(current.get('us_aqi', 42))
                weather_data['pm2_5'] = round(float(current.get('pm2_5', 10.0)), 1)
                weather_data['pm10'] = round(float(current.get('pm10', 20.0)), 1)
    except Exception:
        pass

    # 3. Interpret UV Index Levels
    uv = weather_data['uv_index']
    if uv >= 11:
        weather_data['uv_level'] = 'Extreme Danger'
        weather_data['uv_color'] = 'danger'
        weather_data['health_advisories'].append({
            'title': 'Extreme UV Index Alert',
            'severity': 'danger',
            'icon': 'fa-sun',
            'message': f'UV index is extremely dangerous ({uv}). Unprotected skin can burn within 10 minutes. Stay indoors or use SPF 50+, UV sunglasses, and full protective cover.',
            'category': 'weather'
        })
    elif uv >= 8:
        weather_data['uv_level'] = 'Very High'
        weather_data['uv_color'] = 'warning'
        weather_data['health_advisories'].append({
            'title': 'High Solar Radiation & UV Alert',
            'severity': 'warning',
            'icon': 'fa-sun',
            'message': f'High UV index ({uv}). Wear protective hat, SPF 30+ sunscreen, and seek shade during peak midday hours (11:00 - 15:00).',
            'category': 'weather'
        })
    elif uv >= 6:
        weather_data['uv_level'] = 'High'
        weather_data['uv_color'] = 'warning'
    elif uv >= 3:
        weather_data['uv_level'] = 'Moderate'
        weather_data['uv_color'] = 'info'
    else:
        weather_data['uv_level'] = 'Low'
        weather_data['uv_color'] = 'success'

    # 4. Interpret Temperature & Heat Index
    temp = weather_data['temperature']
    feels = weather_data['apparent_temperature']
    if temp >= 33 or feels >= 35:
        weather_data['health_advisories'].append({
            'title': 'Extreme Heat & Dehydration Hazard',
            'severity': 'danger',
            'icon': 'fa-temperature-high',
            'message': f'High ambient temperature ({temp}°C, feels like {feels}°C) in Kimberley. Drink at least 2.5–3L of water, avoid vigorous outdoor training, and visit Campus Clinic water stations.',
            'category': 'weather'
        })
    elif temp >= 28:
        weather_data['health_advisories'].append({
            'title': 'Campus Warm Weather Hydration Advisory',
            'severity': 'info',
            'icon': 'fa-tint',
            'message': f'Temperatures reaching {temp}°C. Keep a refillable water bottle handy and stay hydrated between lectures.',
            'category': 'weather'
        })
    elif temp <= 8:
        weather_data['health_advisories'].append({
            'title': 'Cold Weather & Hypothermia Advisory',
            'severity': 'warning',
            'icon': 'fa-snowflake',
            'message': f'Low Kimberley morning temperature ({temp}°C). Dress in warm thermal layers; students prone to asthma or cold-induced bronchospasm should keep rescue inhalers accessible.',
            'category': 'weather'
        })

    # 5. Interpret Air Quality Index (AQI)
    aqi = weather_data['aqi']
    if aqi > 100:
        weather_data['aqi_level'] = 'Unhealthy for Sensitive Groups'
        weather_data['aqi_color'] = 'danger'
        weather_data['health_advisories'].append({
            'title': 'Air Quality & Respiratory Warning',
            'severity': 'warning',
            'icon': 'fa-lungs',
            'message': f'Elevated particulate matter (AQI {aqi}, PM2.5 {weather_data["pm2_5"]}µg/m³). Students with asthma or seasonal allergies are advised to limit outdoor endurance sports.',
            'category': 'air_quality'
        })
    elif aqi > 50:
        weather_data['aqi_level'] = 'Moderate'
        weather_data['aqi_color'] = 'warning'
    else:
        weather_data['aqi_level'] = 'Good'
        weather_data['aqi_color'] = 'success'

    _CACHE['weather'] = weather_data
    _CACHE['weather_ts'] = now
    return weather_data


def fetch_live_health_news():
    """
    Fetches curated health news bulletins from authoritative public RSS feeds
    (SANews Health, WHO, BBC Health) with fallback content.
    """
    now = time.time()
    if _CACHE['news'] and (now - _CACHE['news_ts'] < CACHE_TTL_NEWS):
        return _CACHE['news']

    news_items = []

    # Feed sources
    sources = [
        {
            'url': 'https://www.sanews.gov.za/rss.xml',
            'source_name': 'SAnews (South Africa)',
            'badge': 'bg-success',
        },
        {
            'url': 'https://www.who.int/rss-feeds/news-english.xml',
            'source_name': 'World Health Organization',
            'badge': 'bg-primary',
        },
        {
            'url': 'https://feeds.bbci.co.uk/news/health/rss.xml',
            'source_name': 'BBC Health',
            'badge': 'bg-danger',
        }
    ]

    for src in sources:
        try:
            req = urllib.request.Request(
                src['url'],
                headers={'User-Agent': 'CampusCare-HealthNews/1.0'}
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status == 200:
                    xml_content = resp.read()
                    root = ET.fromstring(xml_content)
                    items = root.findall('.//item')
                    for item in items[:4]:
                        title = (item.findtext('title') or '').strip()
                        link = (item.findtext('link') or '').strip()
                        pub_date = (item.findtext('pubDate') or '').strip()
                        desc = (item.findtext('description') or '').strip()
                        
                        # Strip HTML tags from description if present
                        if '<' in desc and '>' in desc:
                            import re
                            desc = re.sub(r'<[^>]+>', '', desc).strip()
                        
                        if len(desc) > 180:
                            desc = desc[:177] + '...'

                        if title:
                            news_items.append({
                                'title': title,
                                'link': link,
                                'pub_date': pub_date[:16] if pub_date else 'Recent',
                                'description': desc,
                                'source': src['source_name'],
                                'badge': src['badge'],
                            })
        except Exception:
            continue

    # Fallback curated health updates if offline
    if not news_items:
        news_items = [
            {
                'title': 'National Department of Health: Vaccination and Wellness Drives for Universities',
                'link': 'https://www.health.gov.za/',
                'pub_date': 'September 2026',
                'description': 'Students and faculty are encouraged to maintain up-to-date immunizations and participate in campus health awareness initiatives.',
                'source': 'SA Health',
                'badge': 'bg-success'
            },
            {
                'title': 'WHO Guidelines on Heatwave Resilience and Hydration Standards',
                'link': 'https://www.who.int/',
                'pub_date': 'September 2026',
                'description': 'Public health recommendations for educational institutions during high solar irradiance and elevated temperature periods.',
                'source': 'WHO Bulletin',
                'badge': 'bg-primary'
            },
            {
                'title': 'Seasonal Respiratory Health and Airborne Allergy Prevention Strategies',
                'link': 'https://www.nicd.ac.za/',
                'pub_date': 'September 2026',
                'description': 'NICD insights on managing seasonal airborne allergens, pollen peaks, and staying protected against respiratory viral transmissions.',
                'source': 'NICD South Africa',
                'badge': 'bg-info'
            }
        ]

    _CACHE['news'] = news_items[:12]
    _CACHE['news_ts'] = now
    return _CACHE['news']


def sync_live_weather_health_alerts():
    """
    Ensures that active real-time meteorological health risks are automatically
    mirrored into the HealthAlert database table so they trigger student dashboard
    popups and unread badge counters.
    """
    weather = fetch_kimberley_weather()
    advisories = weather.get('health_advisories', [])

    for adv in advisories:
        title = adv['title']
        # Check if an active alert with this title already exists
        existing = HealthAlert.objects.filter(title=title, is_active=True).first()
        if not existing:
            HealthAlert.objects.create(
                title=title,
                message=adv['message'],
                severity=adv['severity'],
                category=adv.get('category', 'weather'),
                source='Sol Plaatje University Campus Meteorology',
                is_active=True
            )

    # Ensure baseline clinic alert exists if no alerts present at all
    if not HealthAlert.objects.filter(is_active=True).exists():
        HealthAlert.objects.create(
            title='Campus Clinic Free Wellness & Hydration Advisory',
            message='Visit the Campus Care Clinic at Central Campus for free health screenings, vitals checkups, and electrolyte hydration packs.',
            severity='info',
            category='campus',
            source='Campus Care Clinic',
            is_active=True
        )
