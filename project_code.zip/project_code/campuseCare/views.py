import os
import uuid
import json
import random
from datetime import date, datetime, timedelta
from io import BytesIO

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, FileResponse, JsonResponse
from django.db import transaction
from django.db.models import Count, Q, Avg, Case, When, Value, IntegerField
from django.utils import timezone
from django.conf import settings

from .models import (
    Appointment, Student, Staff, Notification, HealthAlert,
    StaffAvailability, EmergencySlot, MedicalRecord, Report,
    StaffLunchBreak, EmergencyAnnouncement, WaitlistEntry,
    ExternalReferral, HealthAnomalyAlert, ManagementReport,
    StudentHealthAlertRead, PasswordResetOTP
)
from .triage_engine import evaluate_triage, trigger_emergency_clinical_alert
from .notifications import (
    dispatch_booking_received, dispatch_booking_approval,
    dispatch_decline_notification,
    dispatch_cancellation_notification, dispatch_actionable_reminder,
    dispatch_waitlist_offer_notification, send_notification,
    notify_user_with_sms
)
from .sms_service import send_sms, send_phone_saved_sms, normalize_phone_number, is_valid_south_african_phone
from .models import SMSLog
from .waitlist_service import handle_slot_cancellation_and_waitlist
from .reminder_engine import process_all_reminders, trigger_test_reminder
from .anomaly_detector import run_health_anomaly_detection
from .pdf_generator import generate_clinic_management_pdf
from .health_data_service import (
    fetch_kimberley_weather, fetch_live_health_news,
    sync_live_weather_health_alerts
)


# ==============================================================================
# ROLE-BASED ACCESS CONTROL (RBAC) DECORATORS & HELPERS
# ==============================================================================

def clinical_staff_required(view_func):
    """
    Enforces strict Role-Based Access Control.
    Only authorized clinical personnel (nurses, doctors, counsellors) or superusers
    may access clinical consultation histories and sensitive medical records.
    """
    @login_required
    def _wrapped(request, *args, **kwargs):
        try:
            staff = Staff.objects.get(user=request.user)
            if staff.is_clinical or request.user.is_superuser:
                return view_func(request, *args, **kwargs)
        except Staff.DoesNotExist:
            pass
        return HttpResponse(
            'Access Denied: You do not have clinical authorization to view patient medical records.',
            status=403
        )
    return _wrapped


def management_required(view_func):
    """
    Enforces access control for clinic management analytics and executive reporting.
    """
    @login_required
    def _wrapped(request, *args, **kwargs):
        try:
            staff = Staff.objects.get(user=request.user)
            if staff.is_management or staff.is_clinical or request.user.is_superuser:
                return view_func(request, *args, **kwargs)
        except Staff.DoesNotExist:
            if request.user.is_superuser or request.user.is_staff:
                return view_func(request, *args, **kwargs)
        return HttpResponse('Access Denied: Management authorization required.', status=403)
    return _wrapped


# ==============================================================================
# AUTHENTICATION & ONBOARDING
# ==============================================================================

def register(request):
    if request.method == "POST":
        username = request.POST['username']

        if User.objects.filter(username=username).exists():
            return render(request, 'register.html', {'error': 'Username already exists. Please choose a different username.'})

        if Student.objects.filter(student_number=request.POST['student_number']).exists():
            return render(request, 'register.html', {'error': 'Student number already registered.'})

        user = User.objects.create_user(
            username=username,
            password=request.POST['password1'],
            email=request.POST.get('email', ''),
            first_name=request.POST.get('first_name', ''),
            last_name=request.POST.get('last_name', '')
        )

        student = Student.objects.create(
            user=user,
            student_number=request.POST['student_number'],
            phone=request.POST.get('phone', ''),
            date_of_birth=request.POST.get('date_of_birth', None) or None,
            gender=request.POST.get('gender', ''),
            faculty=request.POST.get('faculty', ''),
            year_of_study=request.POST.get('year_of_study', None) or None,
        )

        if student.phone:
            send_phone_saved_sms(student.phone, recipient_name=user.first_name, user_obj=user)

        return redirect('login')

    return render(request, 'register.html')


def register_staff(request):
    if request.method == "POST":
        username = request.POST['username']

        if User.objects.filter(username=username).exists():
            return render(request, 'register_staff.html', {'error': 'Username already exists.'})

        if Staff.objects.filter(staff_id=request.POST['staff_id']).exists():
            return render(request, 'register_staff.html', {'error': 'Staff ID already registered.'})

        user = User.objects.create_user(
            username=username,
            password=request.POST['password1'],
            email=request.POST.get('email', ''),
            first_name=request.POST.get('first_name', ''),
            last_name=request.POST.get('last_name', '')
        )
        user.is_staff = True
        user.save()

        staff = Staff.objects.create(
            user=user,
            staff_id=request.POST['staff_id'],
            phone=request.POST.get('phone', ''),
            role=request.POST.get('role', 'nurse')
        )

        if staff.phone:
            send_phone_saved_sms(staff.phone, recipient_name=user.first_name, user_obj=user)

        # Automatically assign standard working hours and fixed institutional lunch schedule (13:00 - 14:00)
        from datetime import time
        for day in range(5):
            StaffAvailability.objects.get_or_create(
                staff=staff,
                day_of_week=day,
                defaults={'start_time': time(8, 0), 'end_time': time(17, 0), 'is_available': True}
            )
        staff.ensure_fixed_lunch_breaks()

        return redirect('login')

    return render(request, 'register_staff.html')


def login_view(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is None:
            return render(request, 'login.html', {'error': 'Invalid username or password'})

        try:
            Student.objects.get(user=user)
            login(request, user)
            return redirect('student_dashboard')
        except Student.DoesNotExist:
            pass

        try:
            staff = Staff.objects.get(user=user)
            login(request, user)
            if staff.role == 'management':
                return redirect('management_analytics_dashboard')
            return redirect('staff_dashboard')
        except Staff.DoesNotExist:
            pass

        if user.is_superuser:
            login(request, user)
            return redirect('staff_dashboard')

        return render(request, 'login.html', {'error': 'Account not found. Please register.'})

    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


# ==============================================================================
# PASSWORD RESET VIA SMS OTP (Forgot Password Flow)
# ==============================================================================

def _get_registered_phone(user):
    """Return the South African cell number registered on a user's student/staff profile."""
    student = Student.objects.filter(user=user).first()
    if student and student.phone:
        return student.phone
    staff = Staff.objects.filter(user=user).first()
    if staff and staff.phone:
        return staff.phone
    return None


def _mask_phone(phone):
    """Mask a normalized +27XXXXXXXXX number, e.g. +27821234567 -> +2782****567."""
    phone = str(phone or '')
    if len(phone) <= 6:
        return phone
    return f"{phone[:6]}****{phone[-3:]}"


def forgot_password(request):
    """Step 1: identify the user and SMS a random 4-digit OTP to their registered number."""
    if request.method == "POST":
        identifier = (request.POST.get('identifier') or '').strip()
        user = (
            User.objects.filter(username__iexact=identifier).first()
            or User.objects.filter(email__iexact=identifier).first()
        )

        if not user:
            return render(request, 'forgot_password.html', {
                'error': 'No account was found with that username or email address.'
            })

        phone = _get_registered_phone(user)
        if not phone:
            return render(request, 'forgot_password.html', {
                'error': 'This account has no registered cellphone number. Please contact the clinic to update your profile.'
            })

        if not is_valid_south_african_phone(phone):
            return render(request, 'forgot_password.html', {
                'error': 'The cellphone number on this account is not a valid South African number. Please contact the clinic.'
            })

        # Invalidate any previous unused OTPs for this user
        PasswordResetOTP.objects.filter(user=user, is_used=False).update(is_used=True)

        otp_code = f"{random.randint(0, 9999):04d}"
        otp = PasswordResetOTP.objects.create(
            user=user,
            otp_code=otp_code,
            phone_number=normalize_phone_number(phone),
            expires_at=timezone.now() + timedelta(minutes=10),
        )

        sms_message = (
            f"CampusCare: Your password reset code is {otp_code}. "
            f"It expires in 10 minutes. Do not share this code with anyone."
        )
        send_sms(phone, sms_message, user_obj=user, message_type='general')

        request.session['reset_otp_id'] = otp.id
        return redirect('verify_reset_otp')

    return render(request, 'forgot_password.html')


def verify_reset_otp(request):
    """Step 2: verify the 4-digit OTP the user received by SMS."""
    otp_id = request.session.get('reset_otp_id')
    if not otp_id:
        return redirect('forgot_password')

    otp = PasswordResetOTP.objects.filter(id=otp_id, is_used=False).first()
    if not otp:
        return redirect('forgot_password')

    if request.method == "POST":
        entered = (request.POST.get('otp_code') or '').strip()

        if otp.is_expired():
            return render(request, 'verify_otp.html', {
                'error': 'This code has expired. Please request a new reset code.',
                'expired': True,
                'masked_phone': _mask_phone(otp.phone_number),
            })

        if entered != otp.otp_code:
            return render(request, 'verify_otp.html', {
                'error': 'Incorrect code. Please check the SMS and try again.',
                'masked_phone': _mask_phone(otp.phone_number),
            })

        otp.is_verified = True
        otp.save(update_fields=['is_verified'])
        request.session['reset_verified_otp_id'] = otp.id
        return redirect('reset_password')

    return render(request, 'verify_otp.html', {'masked_phone': _mask_phone(otp.phone_number)})


def reset_password(request):
    """Step 3: set and confirm the new password, then return the user to login."""
    otp_id = request.session.get('reset_verified_otp_id')
    if not otp_id:
        return redirect('forgot_password')

    otp = PasswordResetOTP.objects.filter(id=otp_id, is_verified=True, is_used=False).first()
    if not otp or otp.is_expired():
        messages.error(request, 'Your password reset session has expired. Please start again.')
        return redirect('forgot_password')

    if request.method == "POST":
        password1 = request.POST.get('password1') or ''
        password2 = request.POST.get('password2') or ''

        if len(password1) < 8:
            return render(request, 'reset_password.html', {
                'error': 'Password must be at least 8 characters long.'
            })

        if password1 != password2:
            return render(request, 'reset_password.html', {
                'error': 'The two passwords do not match. Please try again.'
            })

        user = otp.user
        user.set_password(password1)
        user.save()

        otp.is_used = True
        otp.save(update_fields=['is_used'])

        request.session.pop('reset_otp_id', None)
        request.session.pop('reset_verified_otp_id', None)

        messages.success(request, 'Your password has been reset successfully. Please sign in with your new password.')
        return redirect('login')

    return render(request, 'reset_password.html')


# ==============================================================================
# CALENDAR & TIME SLOT UTILITIES
# ==============================================================================

def get_weekly_calendar_data(start_date=None):
    if start_date is None:
        today = date.today()
        start_date = today - timedelta(days=today.weekday())
    week_days = []
    for i in range(7):
        d = start_date + timedelta(days=i)
        week_days.append({
            'date': d,
            'day_name': d.strftime('%A'),
            'day_short': d.strftime('%a'),
            'day_num': d.strftime('%d'),
            'month': d.strftime('%b'),
            'is_today': d == date.today(),
            'is_past': d < date.today(),
        })
    return week_days, start_date, start_date + timedelta(days=6)


def generate_timeslots(start_time_str, end_time_str, interval_minutes=30):
    start = datetime.strptime(start_time_str, '%H:%M')
    end = datetime.strptime(end_time_str, '%H:%M')
    slots = []
    current = start
    while current < end:
        slot_end = current + timedelta(minutes=interval_minutes)
        slots.append({
            'start': current.strftime('%H:%M'),
            'end': slot_end.strftime('%H:%M'),
            'label': f"{current.strftime('%H:%M')} - {slot_end.strftime('%H:%M')}"
        })
        current = slot_end
    return slots


def get_available_slots_api(request):
    """
    Interactive API for browsing open appointment slots dynamically.
    Filters out lunch breaks, emergency reservations, and already booked appointments.
    """
    staff_id = request.GET.get('staff_id')
    date_str = request.GET.get('date')

    if not staff_id or not date_str:
        return JsonResponse({'slots': [], 'error': 'staff_id and date required'}, status=400)

    try:
        appt_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        return JsonResponse({'slots': [], 'error': 'Invalid date format'}, status=400)

    staff = get_object_or_404(Staff, pk=staff_id)
    day_num = appt_date.weekday()

    # 1. Staff Availability
    availabilities = staff.availability_slots.filter(day_of_week=day_num, is_available=True)
    if not availabilities.exists():
        return JsonResponse({'slots': [], 'message': 'Practitioner does not have scheduled hours on this day.'})

    # 2. Lunch Breaks (Enforce institutional fixed lunch 13:00 - 14:00)
    lunch_breaks = staff.lunch_breaks.filter(day_of_week=day_num, is_active=True)
    lunch_spans = [('13:00', '14:00')]
    for lb in lunch_breaks:
        lunch_spans.append((lb.start_time.strftime('%H:%M'), lb.end_time.strftime('%H:%M')))

    # 3. Emergency Slots Reserved
    emergency_times = set(
        EmergencySlot.objects.filter(staff=staff, date=appt_date, is_available=False)
        .values_list('time', flat=True)
    )
    emergency_times_str = {t.strftime('%H:%M') for t in emergency_times}

    # 4. Booked Active Appointments
    booked_times = set(
        Appointment.objects.filter(assigned_staff=staff, appointment_date=appt_date)
        .exclude(status='cancelled')
        .values_list('appointment_time', flat=True)
    )
    booked_times_str = {t.strftime('%H:%M') for t in booked_times}

    now = timezone.localtime() if timezone.is_aware(timezone.now()) else datetime.now()
    is_today = (appt_date == now.date())

    available_slots = []
    for avail in availabilities:
        raw_slots = generate_timeslots(avail.start_time.strftime('%H:%M'), avail.end_time.strftime('%H:%M'))
        for s in raw_slots:
            t_str = s['start']

            # Check if past
            if is_today:
                slot_time = datetime.strptime(t_str, '%H:%M').time()
                if slot_time <= now.time():
                    continue

            # Check lunch
            in_lunch = any(start <= t_str < end for start, end in lunch_spans)
            if in_lunch:
                continue

            # Check emergency reservation
            if t_str in emergency_times_str:
                continue

            # Check already booked
            if t_str in booked_times_str:
                continue

            available_slots.append({
                'time': t_str,
                'label': s['label']
            })

    return JsonResponse({'slots': available_slots, 'count': len(available_slots)})


# ==============================================================================
# STUDENT BOOKING PORTAL, TRIAGE & ANONYMOUS APPOINTMENTS
# ==============================================================================

@login_required
def book_appointment(request):
    """
    Student booking portal with digital intake form, triage engine,
    strict anti-double-booking database constraints & locking,
    and fully anonymized booking options for Mental & Sexual health.
    """
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    available_staff = Staff.objects.all()
    staff_list = []
    for staff in available_staff:
        availabilities = staff.availability_slots.filter(is_available=True)
        staff_list.append({
            'staff': staff,
            'availabilities': availabilities,
        })

    if request.method == "POST":
        staff_id = request.POST.get('staff_id')
        staff_member = Staff.objects.get(pk=staff_id) if staff_id else None
        appt_date_str = request.POST.get('appointment_date')
        appt_time_str = request.POST.get('appointment_time')
        category = request.POST.get('category')
        symptoms = request.POST.get('symptoms', '').strip()
        intake_duration = request.POST.get('intake_duration', '<24h')
        intake_pain = request.POST.get('intake_pain_scale', 0)
        red_flags_list = request.POST.getlist('red_flags')
        is_anonymous = bool(request.POST.get('is_anonymous'))

        if not staff_member or not appt_date_str or not appt_time_str or not category:
            messages.error(request, 'Please complete all required booking fields.')
            return redirect('book_appointment')

        # Restriction: Anonymous bookings are ONLY allowed for Mental Health or Sexual Health
        if is_anonymous and category not in ['mental', 'sexual']:
            messages.error(
                request,
                'Anonymous booking is strictly reserved for Mental Health and Sexual/Reproductive Health consultations.'
            )
            return redirect('book_appointment')

        # Database-level concurrency control & locking
        try:
            if isinstance(appt_date_str, str):
                parsed_date = datetime.strptime(appt_date_str, '%Y-%m-%d').date()
            else:
                parsed_date = appt_date_str
            if isinstance(appt_time_str, str):
                parsed_time = datetime.strptime(appt_time_str[:5], '%H:%M').time()
            else:
                parsed_time = appt_time_str
        except (ValueError, TypeError):
            parsed_date = appt_date_str
            parsed_time = appt_time_str

        # Strict Institutional Lunch Hour Enforcement (13:00 - 14:00)
        # Cannot be booked unless it is an emergency case
        from datetime import time as dt_time
        if parsed_time and dt_time(13, 0) <= parsed_time < dt_time(14, 0):
            is_emergency_booking = (category == 'emergency') or any(
                f in red_flags_list for f in ['chest_pain', 'breathing', 'suicidal', 'severe_bleeding', 'unconscious', 'anaphylaxis']
            )
            if not is_emergency_booking:
                messages.error(
                    request,
                    'Fixed Lunch Policy: Staff lunch is locked between 13:00 and 14:00 and cannot be booked unless of clinical emergencies.'
                )
                return redirect('book_appointment')

        try:
            with transaction.atomic():
                # Lock and check if slot is already reserved
                conflict = Appointment.objects.select_for_update().filter(
                    assigned_staff=staff_member,
                    appointment_date=parsed_date,
                    appointment_time=parsed_time
                ).exclude(status='cancelled').first()

                if conflict:
                    messages.error(
                        request,
                        'This time slot was just booked by another student. Please select an alternate slot or join the waitlist.'
                    )
                    return redirect('book_appointment')

                # Run Clinical Triage Engine
                triage_result = evaluate_triage(
                    category=category,
                    symptoms_text=symptoms,
                    duration_str=intake_duration,
                    pain_scale=intake_pain,
                    red_flags=red_flags_list
                )

                priority = triage_result['priority']
                triage_notes = triage_result['triage_notes']

                # Create Appointment
                if is_anonymous:
                    # STRUCTURAL DISASSOCIATION:
                    # student=None permanently disassociates the record from any student FK/join table.
                    anon_code = f"ANON-{category[:2].upper()}-{uuid.uuid4().hex[:6].upper()}"
                    anon_token = uuid.uuid4()

                    appt = Appointment.objects.create(
                        student=None,
                        assigned_staff=staff_member,
                        category=category,
                        urgency=priority,
                        appointment_date=parsed_date,
                        appointment_time=parsed_time,
                        symptoms=symptoms,
                        intake_duration=intake_duration,
                        intake_pain_scale=intake_pain,
                        intake_red_flags=red_flags_list,
                        triage_notes=triage_notes,
                        triage_timestamp=timezone.now(),
                        is_anonymous=True,
                        anonymous_code=anon_code,
                        anonymous_token=anon_token,
                        status='pending'
                    )
                else:
                    appt = Appointment.objects.create(
                        student=student,
                        assigned_staff=staff_member,
                        category=category,
                        urgency=priority,
                        appointment_date=parsed_date,
                        appointment_time=parsed_time,
                        symptoms=symptoms,
                        intake_duration=intake_duration,
                        intake_pain_scale=intake_pain,
                        intake_red_flags=red_flags_list,
                        triage_notes=triage_notes,
                        triage_timestamp=timezone.now(),
                        is_anonymous=False,
                        status='pending'
                    )

        except Exception as e:
            messages.error(request, f'Slot reservation conflict or system error: {str(e)}')
            return redirect('book_appointment')

        # Trigger Immediate Real-Time Alert to Clinical Staff if Emergency
        if triage_result['is_emergency']:
            trigger_emergency_clinical_alert(appt)
            messages.warning(
                request,
                'EMERGENCY PRIORITY DETECTED: Clinical staff have received an immediate real-time alert. '
                'If you are in acute distress or need immediate campus security assistance, please call Campus Emergency.'
            )

        # Dispatch instant "booking received" advisory (In-app, Email, SMS).
        # The appointment stays PENDING until a staff member accepts it.
        dispatch_booking_received(appt)

        if is_anonymous:
            # Redirect to secure anonymous confirmation view displaying token & reference
            return redirect('anonymous_booking_view', token=appt.anonymous_token)

        messages.success(request, 'Your booking request has been sent to the clinic. You will receive an SMS and email confirmation once a staff member accepts it.')
        return redirect('my_appointments')

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'book_appointment.html', {
        'user_type': 'student',
        'category_choices': Appointment.CATEGORY_CHOICES,
        'staff_list': staff_list,
        'unread_count': unread_count,
        'today': date.today().isoformat(),
    })


def anonymous_booking_view(request, token):
    """
    Secure view for students who booked an anonymous consultation.
    Accessible solely via their secret anonymous token without requiring login.
    """
    appt = get_object_or_404(Appointment, anonymous_token=token, is_anonymous=True)

    if request.method == "POST":
        action = request.POST.get('action')
        if action == 'cancel':
            appt.status = 'cancelled'
            appt.save()
            handle_slot_cancellation_and_waitlist(appt)
            messages.success(request, 'Your anonymous appointment has been cancelled and the slot has been released.')
            return redirect('anonymous_booking_view', token=token)

    return render(request, 'anonymous_booking_view.html', {
        'appt': appt,
    })


def appointment_action_view(request, token):
    """
    Direct actionable endpoint accessed from automated reminder notifications (Email / SMS).
    Allows student to Confirm, Reschedule, or Cancel directly from the reminder notification itself.
    """
    appt = get_object_or_404(Appointment, action_token=token)
    action = request.GET.get('action') or request.POST.get('action')

    if action == 'confirm':
        appt.status = 'confirmed'
        appt.save(update_fields=['status'])
        return render(request, 'appointment_action_result.html', {
            'appt': appt,
            'action': 'confirm',
            'message': 'Thank you! Your attendance has been confirmed.'
        })

    elif action == 'cancel':
        if appt.status != 'cancelled':
            appt.status = 'cancelled'
            appt.save(update_fields=['status'])
            # Automatically reassign released slot to waitlisted students in priority order
            handle_slot_cancellation_and_waitlist(appt)
            dispatch_cancellation_notification(appt, cancelled_by='student')
        return render(request, 'appointment_action_result.html', {
            'appt': appt,
            'action': 'cancel',
            'message': 'Your appointment has been cancelled. The slot has been automatically offered to waiting students.'
        })

    elif action == 'reschedule':
        if request.method == "POST":
            new_date = request.POST.get('appointment_date')
            new_time = request.POST.get('appointment_time')
            if new_date and new_time:
                # Check conflict
                conflict = Appointment.objects.filter(
                    assigned_staff=appt.assigned_staff,
                    appointment_date=new_date,
                    appointment_time=new_time
                ).exclude(status='cancelled').first()

                if conflict:
                    messages.error(request, 'Selected new time slot is unavailable. Please choose another.')
                else:
                    old_appt = appt
                    appt.appointment_date = new_date
                    appt.appointment_time = new_time
                    appt.status = 'confirmed'
                    appt.save()
                    handle_slot_cancellation_and_waitlist(old_appt)
                    return render(request, 'appointment_action_result.html', {
                        'appt': appt,
                        'action': 'reschedule',
                        'message': f'Your appointment has been rescheduled to {new_date} at {new_time}.'
                    })

        return render(request, 'appointment_action_reschedule.html', {
            'appt': appt,
            'today': date.today().isoformat(),
        })

    return redirect('login')


@login_required
def join_waitlist(request):
    """
    Adds a student to the waitlist when their desired appointment slot is occupied.
    """
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    if request.method == "POST":
        staff_id = request.POST.get('staff_id')
        staff_member = Staff.objects.get(pk=staff_id) if staff_id else None
        pref_date = request.POST.get('preferred_date')
        category = request.POST.get('category')
        symptoms = request.POST.get('symptoms', '')
        duration = request.POST.get('intake_duration', '<24h')
        pain = request.POST.get('intake_pain_scale', 0)
        red_flags = request.POST.getlist('red_flags')

        triage_res = evaluate_triage(category, symptoms, duration, pain, red_flags)

        WaitlistEntry.objects.create(
            student=student,
            preferred_staff=staff_member,
            preferred_date=pref_date,
            category=category,
            symptoms=symptoms,
            intake_duration=duration,
            intake_pain_scale=pain,
            intake_red_flags=red_flags,
            urgency=triage_res['priority'],
            status='waiting'
        )

        messages.success(request, 'You have been added to the waiting list. If a slot opens up, you will be notified in order of your priority level.')
        return redirect('student_dashboard')

    return redirect('book_appointment')


# ==============================================================================
# STUDENT DASHBOARD, APPOINTMENTS & HEALTH SUMMARY
# ==============================================================================

@login_required
def student_dashboard(request):
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    appointments = Appointment.objects.filter(student=student)
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    week_days, week_start, week_end = get_weekly_calendar_data()

    week_appointments = appointments.filter(
        appointment_date__gte=week_start,
        appointment_date__lte=week_end
    ).exclude(status='cancelled')

    # Calendar events grouped by date string
    calendar_events = {}
    for appt in week_appointments:
        date_str = appt.appointment_date.isoformat()
        if date_str not in calendar_events:
            calendar_events[date_str] = []
        calendar_events[date_str].append(appt)

    # Attach appointments list directly to day object so template can render easily
    for day in week_days:
        day['appts'] = calendar_events.get(day['date'].isoformat(), [])

    active_emergencies = EmergencyAnnouncement.objects.filter(is_active=True).select_related('staff')

    # Synchronize live meteorological and health alerts
    sync_live_weather_health_alerts()
    weather = fetch_kimberley_weather()

    # Track read status for active alerts
    read_alert_ids = set(StudentHealthAlertRead.objects.filter(user=request.user).values_list('alert_id', flat=True))
    all_active_alerts = list(HealthAlert.objects.filter(is_active=True).order_by('-created_at')[:6])
    for a in all_active_alerts:
        a.is_read = a.id in read_alert_ids

    unseen_alerts = [a for a in all_active_alerts if not a.is_read]

    available_staff = Staff.objects.all()
    staff_list = []
    for staff in available_staff:
        availabilities = staff.availability_slots.filter(is_available=True)
        staff_list.append({
            'staff': staff,
            'availabilities': availabilities,
        })

    ordered_appts = appointments.order_by('-appointment_date', '-appointment_time', '-id')
    latest_appointment = ordered_appts.first()

    context = {
        'user_type': 'student',
        'confirmed': appointments.filter(status='confirmed').count(),
        'pending': appointments.filter(status='pending').count(),
        'completed': appointments.filter(status='completed').count(),
        'cancelled': appointments.filter(status='cancelled').count(),
        'appointments': ordered_appts,
        'latest_appointment': latest_appointment,
        'staff_list': staff_list,
        'unread_count': unread_count,
        'week_days': week_days,
        'week_start': week_start,
        'week_end': week_end,
        'active_emergencies': active_emergencies,
        'alerts': all_active_alerts,
        'unseen_alerts': unseen_alerts,
        'active_popups': unseen_alerts[:2],
        'weather': weather,
    }

    return render(request, 'student_dashboard.html', context)


@login_required
def my_appointments(request):
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    appointments = Appointment.objects.filter(student=student).order_by('-appointment_date', '-appointment_time')
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'my_appointments.html', {
        'user_type': 'student',
        'appointments': appointments,
        'unread_count': unread_count
    })


@login_required
def appointment_detail(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    is_student = Student.objects.filter(user=request.user).exists()
    is_staff = Staff.objects.filter(user=request.user).exists()
    user_type = 'student' if is_student else 'staff' if is_staff else None

    reports = appt.reports.all()

    if request.method == "POST" and is_student:
        new_date = request.POST.get('appointment_date')
        new_time = request.POST.get('appointment_time')
        if new_date and new_time:
            # Check slot conflict
            conflict = Appointment.objects.filter(
                assigned_staff=appt.assigned_staff,
                appointment_date=new_date,
                appointment_time=new_time
            ).exclude(status='cancelled').first()

            if conflict:
                messages.error(request, 'That time slot is already booked. Please choose another.')
                return redirect('appointment_detail', pk=pk)

            old_appt = appt
            appt.appointment_date = new_date
            appt.appointment_time = new_time
            appt.status = 'confirmed'
            appt.save()

            # Release previous slot
            handle_slot_cancellation_and_waitlist(old_appt)

            messages.success(request, 'Appointment rescheduled successfully.')
            return redirect('my_appointments')

    return render(request, 'appointment_detail.html', {
        'user_type': user_type,
        'appt': appt,
        'unread_count': unread_count,
        'reports': reports,
    })


@login_required
def cancel_appointment(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    old_status = appt.status
    appt.status = 'cancelled'
    appt.save()

    if old_status != 'cancelled':
        # Automatically release slot & offer to waiting list in strict priority order
        handle_slot_cancellation_and_waitlist(appt)
        dispatch_cancellation_notification(appt, cancelled_by='student')
        messages.success(request, 'Appointment cancelled. The slot has been released back into availability.')

    return redirect('my_appointments')


@login_required
def my_health_history(request):
    """
    Student Health History Summary view.
    Allows students to view a summarized version of their own health history,
    past consultation outcomes, diagnoses, and medical reports.
    """
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    completed_appts = Appointment.objects.filter(student=student, status='completed').order_by('-appointment_date')
    records = MedicalRecord.objects.filter(student=student).order_by('-upload_date')
    reports = Report.objects.filter(student=student).order_by('-created_at')
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'my_health_history.html', {
        'user_type': 'student',
        'student': student,
        'completed_appts': completed_appts,
        'records': records,
        'reports': reports,
        'unread_count': unread_count,
    })


@login_required
def my_records(request):
    try:
        student = Student.objects.get(user=request.user)
    except Student.DoesNotExist:
        return redirect('login')

    if request.method == "POST" and request.FILES.get('record_file'):
        uploaded_file = request.FILES['record_file']
        allowed_extensions = ['png', 'jpg', 'jpeg', 'pdf', 'docx', 'doc']
        file_ext = os.path.splitext(uploaded_file.name)[1].lower().lstrip('.')

        if file_ext not in allowed_extensions:
            messages.error(request, f'File type .{file_ext} is not allowed. Please upload PNG, JPEG, PDF, or DOCX files.')
            return redirect('my_records')

        record = MedicalRecord(
            student=student,
            title=request.POST.get('title', f'Record - {date.today()}'),
            record_type=request.POST.get('record_type', 'other'),
            description=request.POST.get('description', ''),
            diagnosis=request.POST.get('diagnosis', ''),
            treatment=request.POST.get('treatment', ''),
            doctor_name=request.POST.get('doctor_name', ''),
            record_file=uploaded_file
        )
        record.save()
        messages.success(request, 'Medical record uploaded successfully!')
        return redirect('my_records')

    records = MedicalRecord.objects.filter(student=student).order_by('-upload_date')
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'records.html', {
        'user_type': 'student',
        'records': records,
        'unread_count': unread_count,
        'record_types': MedicalRecord.RECORD_TYPE_CHOICES,
    })


@login_required
def download_record(request, pk):
    record = get_object_or_404(MedicalRecord, pk=pk)

    try:
        student = Student.objects.get(user=request.user)
        is_owner = record.student == student
    except Student.DoesNotExist:
        is_owner = False

    try:
        staff = Staff.objects.get(user=request.user)
        is_staff = staff.is_clinical or request.user.is_superuser
    except Staff.DoesNotExist:
        is_staff = False

    if not (is_owner or is_staff):
        return HttpResponse('Unauthorized access to confidential health record.', status=403)

    file_path = os.path.join(settings.MEDIA_ROOT, record.record_file.name)
    if os.path.exists(file_path):
        response = FileResponse(open(file_path, 'rb'))
        response['Content-Disposition'] = f'attachment; filename="{record.filename}"'
        return response
    return HttpResponse('File not found', status=404)


# ==============================================================================
# SECURE STAFF DASHBOARD, REAL-TIME QUEUE & INLINE ACTIONS
# ==============================================================================

@login_required
def staff_dashboard(request):
    """
    Clinical and Administrative staff dashboard showing that day's upcoming appointments
    organized FIRST by priority level (Emergency -> Urgent -> Routine) and then by time.
    Supports real-time live updates and inline actions.
    """
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        if request.user.is_superuser:
            staff = Staff.objects.first()
            if not staff:
                return redirect('login')
        else:
            return redirect('login')

    today = date.today()
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    # Ensure fixed lunch breaks for staff member
    if staff:
        staff.ensure_fixed_lunch_breaks()

    # Today's appointments organized strictly by PRIORITY LEVEL then TIME
    # Filtered to show ONLY appointments assigned to this practitioner
    today_appointments = Appointment.objects.filter(
        appointment_date=today,
        assigned_staff=staff
    ).exclude(status='cancelled').annotate(
        priority_rank=Case(
            When(urgency='emergency', then=Value(1)),
            When(urgency='urgent', then=Value(2)),
            When(urgency='routine', then=Value(3)),
            When(urgency='high', then=Value(2)),
            When(urgency='medium', then=Value(2)),
            default=Value(3),
            output_field=IntegerField()
        )
    ).order_by('priority_rank', 'appointment_time')

    total_today = today_appointments.count()
    emergency_today = today_appointments.filter(urgency='emergency').count()
    urgent_today = today_appointments.filter(urgency__in=['urgent', 'high']).count()
    completed_today = today_appointments.filter(status='completed').count()

    active_emergency = EmergencyAnnouncement.objects.filter(staff=staff, is_active=True).first() if staff else None

    # All Bookings (scoped to this practitioner only)
    all_bookings = Appointment.objects.filter(assigned_staff=staff).order_by('-appointment_date', '-appointment_time')
    upcoming_bookings = Appointment.objects.filter(
        assigned_staff=staff,
        appointment_date__gte=today
    ).exclude(status='cancelled').order_by('appointment_date', 'appointment_time')

    # Available Slots calculation for today (08:00 to 17:00 in 30-min intervals)
    emergency_slots_today = set(
        EmergencySlot.objects.filter(staff=staff, date=today, is_available=False).values_list('time', flat=True)
    ) if staff else set()
    emergency_slots_today_str = {t.strftime('%H:%M') for t in emergency_slots_today}

    booked_times_today_map = {
        appt.appointment_time.strftime('%H:%M'): appt
        for appt in today_appointments
    }

    all_day_slots = []
    curr_t = datetime.strptime('08:00', '%H:%M')
    end_t = datetime.strptime('17:00', '%H:%M')
    available_slots_count = 0
    booked_slots_count = 0
    lunch_slots_count = 0

    while curr_t < end_t:
        t_start = curr_t.strftime('%H:%M')
        curr_t += timedelta(minutes=30)
        t_end = curr_t.strftime('%H:%M')
        slot_label = f"{t_start} - {t_end}"

        if '13:00' <= t_start < '14:00':
            slot_status = 'lunch'
            slot_desc = 'Institutional Lunch Break (13:00 – 14:00 Policy)'
            appt_obj = None
            lunch_slots_count += 1
        elif t_start in booked_times_today_map:
            slot_status = 'booked'
            appt_obj = booked_times_today_map[t_start]
            slot_desc = f"Booked: {appt_obj.display_patient_name} ({appt_obj.get_category_display()})"
            booked_slots_count += 1
        elif t_start in emergency_slots_today_str:
            slot_status = 'emergency'
            slot_desc = 'Reserved Emergency Priority Slot'
            appt_obj = None
        else:
            slot_status = 'available'
            slot_desc = 'Available Open Slot'
            appt_obj = None
            available_slots_count += 1

        all_day_slots.append({
            'start': t_start,
            'end': t_end,
            'label': slot_label,
            'status': slot_status,
            'description': slot_desc,
            'appointment': appt_obj,
        })

    context = {
        'user_type': 'staff',
        'staff_obj': staff,
        'today': today,
        'today_appointments': today_appointments,
        'total_today': total_today,
        'emergency_today': emergency_today,
        'urgent_today': urgent_today,
        'completed_today': completed_today,
        'active_emergency': active_emergency,
        'all_day_slots': all_day_slots,
        'available_slots_count': available_slots_count,
        'booked_slots_count': booked_slots_count,
        'lunch_slots_count': lunch_slots_count,
        'all_bookings': all_bookings,
        'upcoming_bookings': upcoming_bookings,
        'alerts': HealthAlert.objects.all()[:4],
        'unread_count': unread_count,
        'available_external_services': [
            'Kimberley Hospital Complex - Crisis Psychiatry',
            'Department of Health Provincial Clinic',
            'SANCA Alcohol & Drug Centre',
            'SPU Student Psychological Services',
            'Robert Mangaliso Sobukwe Hospital',
            'National Sexual Assault Crisis Hotline',
        ]
    }

    return render(request, 'staff_dashboard.html', context)


@login_required
def staff_queue_live_api(request):
    """
    Real-Time JSON API endpoint polled by the staff dashboard every 4 seconds.
    Returns that day's upcoming appointments organized by priority, then time,
    so new bookings, cancellations, or emergency arrivals reflect immediately without manual refresh.
    Scoped to show ONLY appointments assigned to the currently logged-in practitioner.
    """
    today = date.today()

    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        staff = None

    base_qs = Appointment.objects.filter(appointment_date=today)
    if staff:
        base_qs = base_qs.filter(assigned_staff=staff)

    appts = base_qs.exclude(status='cancelled').annotate(
        priority_rank=Case(
            When(urgency='emergency', then=Value(1)),
            When(urgency='urgent', then=Value(2)),
            When(urgency='routine', then=Value(3)),
            When(urgency='high', then=Value(2)),
            When(urgency='medium', then=Value(2)),
            default=Value(3),
            output_field=IntegerField()
        )
    ).order_by('priority_rank', 'appointment_time')

    data = []
    has_active_emergency = False

    for a in appts:
        if a.normalized_urgency == 'emergency' and a.status != 'completed':
            has_active_emergency = True

        data.append({
            'id': a.pk,
            'time': a.appointment_time.strftime('%H:%M'),
            'patient_name': a.display_patient_name,
            'student_number': a.student.student_number if (a.student and not a.is_anonymous) else 'ANONYMOUS',
            'category': a.get_category_display(),
            'urgency': a.normalized_urgency,
            'urgency_display': a.normalized_urgency_display,
            'priority_rank': a.priority_sort_key,
            'status': a.status,
            'status_display': a.get_status_display(),
            'is_anonymous': a.is_anonymous,
            'symptoms': a.symptoms[:120],
            'intake_pain': a.intake_pain_scale,
            'assigned_staff': a.assigned_staff.user.get_full_name() if a.assigned_staff else 'Unassigned'
        })

    return JsonResponse({
        'total': len(data),
        'appointments': data,
        'has_emergency': has_active_emergency,
        'timestamp': timezone.now().strftime('%H:%M:%S')
    })


# ==============================================================================
# INLINE ACTIONS FROM DASHBOARD
# ==============================================================================

@login_required
def inline_complete_appointment(request, pk):
    """
    Marks an appointment as complete and records clinical notes, diagnosis,
    treatment plan, and wait time directly inline without navigating away.
    """
    appt = get_object_or_404(Appointment, pk=pk)

    if request.method == "POST":
        appt.status = 'completed'
        appt.completed_at = timezone.now()
        appt.visit_reason = request.POST.get('visit_reason', appt.visit_reason)
        appt.clinical_notes = request.POST.get('clinical_notes', '')
        appt.diagnosis = request.POST.get('diagnosis', '')
        appt.treatment_plan = request.POST.get('treatment_plan', '')
        appt.save()

        # Optional: Auto-generate visit report if requested
        if request.POST.get('create_report') and appt.student:
            try:
                staff = Staff.objects.get(user=request.user)
                Report.objects.create(
                    appointment=appt,
                    generated_by=staff,
                    student=appt.student,
                    report_type='visit_summary',
                    title=f"Visit Summary - {appt.get_category_display()}",
                    reason_for_visit=appt.visit_reason,
                    diagnosis=appt.diagnosis,
                    treatment=appt.treatment_plan,
                    notes=appt.clinical_notes,
                    visit_date=appt.appointment_date,
                    visit_time=appt.appointment_time
                )
            except Exception:
                pass

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'message': f'Appointment #{appt.pk} marked as completed.'})

        messages.success(request, f'Appointment #{appt.pk} successfully completed.')
        return redirect('staff_dashboard')

    return redirect('staff_dashboard')


@login_required
def inline_external_referral(request, pk):
    """
    Submits an external referral to specialist or hospital facilities
    directly inline from the staff dashboard without leaving the screen.
    """
    appt = get_object_or_404(Appointment, pk=pk)

    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        staff = appt.assigned_staff or Staff.objects.first()

    if request.method == "POST":
        service_name = request.POST.get('service_name', '')
        service_type = request.POST.get('service_type', 'Specialist Care')
        urgency = request.POST.get('urgency', 'urgent')
        reason = request.POST.get('reason', '')
        clinical_summary = request.POST.get('clinical_summary', '')
        contact_info = request.POST.get('contact_info', '')

        referral = ExternalReferral.objects.create(
            appointment=appt,
            student=appt.student,
            referred_by=staff,
            service_name=service_name,
            service_type=service_type,
            urgency=urgency,
            reason=reason,
            clinical_summary=clinical_summary,
            contact_info=contact_info,
            status='pending'
        )

        if appt.student:
            Notification.objects.create(
                user=appt.student.user,
                title="External Referral Issued",
                message=f"A medical referral to {service_name} has been issued by {staff.user.get_full_name()}."
            )

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'referral_id': referral.pk, 'message': f'Referral to {service_name} created.'})

        messages.success(request, f'External referral to {service_name} successfully recorded.')
        return redirect('staff_dashboard')

    return redirect('staff_dashboard')


@login_required
def inline_mark_no_show(request, pk):
    """Marks appointment as no-show directly inline."""
    appt = get_object_or_404(Appointment, pk=pk)
    appt.status = 'no_show'
    appt.save(update_fields=['status'])

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'success': True, 'message': f'Appointment #{appt.pk} marked as No-Show.'})

    messages.info(request, f'Appointment #{appt.pk} marked as No-Show.')
    return redirect('staff_dashboard')


@login_required
def inline_update_student_record(request, student_id):
    """Inline update of patient allergies, blood type, or medical notes."""
    student = get_object_or_404(Student, pk=student_id)

    if request.method == "POST":
        if 'allergies' in request.POST:
            student.allergies = request.POST.get('allergies')
        if 'blood_type' in request.POST:
            student.blood_type = request.POST.get('blood_type')
        if 'emergency_contact_name' in request.POST:
            student.emergency_contact_name = request.POST.get('emergency_contact_name')
        if 'emergency_contact_phone' in request.POST:
            student.emergency_contact_phone = request.POST.get('emergency_contact_phone')
        student.save()

        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'success': True, 'message': 'Student health profile updated.'})

        messages.success(request, 'Student health profile updated.')
        return redirect(request.META.get('HTTP_REFERER', 'staff_dashboard'))

    return redirect('staff_dashboard')


# ==============================================================================
# CLINICAL CONSULTATION HISTORY & RECORDS (STRICT RBAC)
# ==============================================================================

@clinical_staff_required
def staff_view_records(request):
    """
    Enforces strict RBAC: only authorized clinical staff can pull up a student's
    complete consultation history before a session begins.
    """
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        staff = None

    student_id = request.GET.get('student_id')
    search = request.GET.get('search', '')

    if student_id:
        student = get_object_or_404(Student, pk=student_id)
        records = MedicalRecord.objects.filter(student=student).order_by('-upload_date')
        appointments = Appointment.objects.filter(student=student).order_by('-appointment_date')
        reports = Report.objects.filter(student=student).order_by('-created_at')
        referrals = ExternalReferral.objects.filter(student=student).order_by('-created_at')
    else:
        records = []
        appointments = []
        reports = []
        referrals = []
        student = None

    students_with_appts = Student.objects.all().distinct().select_related('user')
    if search:
        students_with_appts = students_with_appts.filter(
            Q(user__first_name__icontains=search) |
            Q(user__last_name__icontains=search) |
            Q(student_number__icontains=search)
        )

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'staff_view_records.html', {
        'user_type': 'staff',
        'records': records,
        'student': student,
        'students_with_appts': students_with_appts[:30],
        'appointments': appointments,
        'reports': reports,
        'referrals': referrals,
        'search': search,
        'unread_count': unread_count,
    })


# ==============================================================================
# MANAGEMENT ANALYTICS, ANOMALY DETECTION & PDF REPORTING
# ==============================================================================

@management_required
def management_analytics_dashboard(request):
    """
    Executive Clinic Analytics Dashboard providing management with key metrics:
    - Daily appointment volumes
    - No-show rates
    - Case type distributions
    - Average patient waiting times
    - Multi-dimensional filters (date range, case type, student demographic)
    - Automated Health Trend Anomaly Detection
    """
    # 1. Date Range Filter
    date_preset = request.GET.get('preset', '30d')
    today = date.today()

    start_date_str = request.GET.get('start_date')
    end_date_str = request.GET.get('end_date')

    if start_date_str and end_date_str:
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date()
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date()
        except ValueError:
            start_date = today - timedelta(days=30)
            end_date = today
    elif date_preset == '7d':
        start_date = today - timedelta(days=7)
        end_date = today
    elif date_preset == '90d':
        start_date = today - timedelta(days=90)
        end_date = today
    else:  # default 30d
        start_date = today - timedelta(days=30)
        end_date = today

    # 2. Category, Demographic & Staff Filters
    category_filter = request.GET.get('category', '')
    faculty_filter = request.GET.get('faculty', '')
    gender_filter = request.GET.get('gender', '')
    year_filter = request.GET.get('year_of_study', '')
    staff_filter = request.GET.get('staff_id', '')

    base_query = Appointment.objects.filter(
        appointment_date__gte=start_date,
        appointment_date__lte=end_date
    )

    if category_filter:
        base_query = base_query.filter(category=category_filter)
    if faculty_filter:
        base_query = base_query.filter(student__faculty=faculty_filter)
    if gender_filter:
        base_query = base_query.filter(student__gender=gender_filter)
    if year_filter:
        base_query = base_query.filter(student__year_of_study=year_filter)
    if staff_filter:
        if staff_filter == 'unassigned':
            base_query = base_query.filter(assigned_staff__isnull=True)
        else:
            base_query = base_query.filter(assigned_staff_id=staff_filter)

    # 3. Key Clinic Performance Metrics
    total_appointments = base_query.count()
    completed_count = base_query.filter(status='completed').count()
    no_show_count = base_query.filter(status='no_show').count()
    cancelled_count = base_query.filter(status='cancelled').count()
    acute_cases_count = base_query.filter(urgency__in=['emergency', 'urgent', 'high']).count()

    no_show_rate = (no_show_count / total_appointments * 100.0) if total_appointments > 0 else 0.0

    # Calculate Average Waiting Time (in minutes)
    completed_appts = base_query.filter(status='completed', completed_at__isnull=False)
    wait_times = [a.wait_time_minutes for a in completed_appts]
    avg_wait_minutes = round(sum(wait_times) / len(wait_times), 1) if wait_times else 12.5

    # 4. Daily Appointment Volumes (Chart Data)
    days_delta = (end_date - start_date).days + 1
    daily_volume = []
    curr_d = start_date
    while curr_d <= end_date:
        cnt = base_query.filter(appointment_date=curr_d).exclude(status='cancelled').count()
        daily_volume.append({
            'date': curr_d.strftime('%Y-%m-%d'),
            'label': curr_d.strftime('%d %b'),
            'count': cnt
        })
        curr_d += timedelta(days=1)

    # 5. Case Type Distribution
    cat_counts = base_query.values('category').annotate(total=Count('id')).order_by('-total')
    category_distribution = []
    for cat_code, cat_name in Appointment.CATEGORY_CHOICES:
        item = next((c for c in cat_counts if c['category'] == cat_code), None)
        tot = item['total'] if item else 0
        pct = (tot / total_appointments * 100.0) if total_appointments > 0 else 0.0
        comp = base_query.filter(category=cat_code, status='completed').count()
        urg = base_query.filter(category=cat_code, urgency__in=['emergency', 'urgent', 'high']).count()
        category_distribution.append({
            'code': cat_code,
            'category': cat_name,
            'total': tot,
            'pct': pct,
            'completed': comp,
            'urgent_count': urg
        })

    # 6. Demographic Distributions
    faculty_counts = base_query.filter(student__isnull=False).values('student__faculty').annotate(count=Count('id')).order_by('-count')
    demographics = []
    for f in faculty_counts:
        fac_name = f['student__faculty'] or 'Unassigned Faculty'
        demographics.append({
            'name': fac_name,
            'count': f['count'],
            'pct': (f['count'] / total_appointments * 100.0) if total_appointments > 0 else 0.0
        })

    # 7. Staff Management & Clinical Workload Analysis
    all_staff_members = Staff.objects.all().select_related('user')
    staff_workload_analysis = []
    for st in all_staff_members:
        st_appts = base_query.filter(assigned_staff=st)
        st_total = st_appts.count()
        st_completed = st_appts.filter(status='completed').count()
        st_pending = st_appts.filter(status__in=['pending', 'confirmed']).count()
        st_noshow = st_appts.filter(status='no_show').count()
        st_rate = round((st_completed / st_total * 100.0), 1) if st_total > 0 else 0.0
        active_hours_count = st.availability_slots.filter(is_available=True).count()

        staff_workload_analysis.append({
            'staff': st,
            'name': st.user.get_full_name() or st.user.username,
            'staff_id': st.staff_id,
            'role': st.get_role_display() if hasattr(st, 'get_role_display') else st.role,
            'total': st_total,
            'completed': st_completed,
            'pending': st_pending,
            'no_show': st_noshow,
            'completion_rate': st_rate,
            'active_hours_slots': active_hours_count,
        })

    # Unassigned bookings count if any
    unassigned_count = base_query.filter(assigned_staff__isnull=True).count()
    if unassigned_count > 0:
        staff_workload_analysis.append({
            'staff': None,
            'name': 'Unassigned / Open Triage Queue',
            'staff_id': 'UNASSIGNED',
            'role': 'General Clinic Queue',
            'total': unassigned_count,
            'completed': base_query.filter(assigned_staff__isnull=True, status='completed').count(),
            'pending': base_query.filter(assigned_staff__isnull=True, status__in=['pending', 'confirmed']).count(),
            'no_show': base_query.filter(assigned_staff__isnull=True, status='no_show').count(),
            'completion_rate': 0.0,
            'active_hours_slots': 0,
        })

    staff_chart_data = [
        {'name': s['name'], 'completed': s['completed'], 'total': s['total']}
        for s in staff_workload_analysis
    ]

    # 8. Run Health Trend Anomaly Detection
    anomalies = run_health_anomaly_detection(reference_date=end_date)
    all_active_anomalies = HealthAnomalyAlert.objects.filter(is_acknowledged=False).order_by('-detected_at')

    # 9. Available Reports
    recent_pdf_reports = ManagementReport.objects.all().order_by('-created_at')[:10]
    faculties = Student.objects.exclude(faculty__isnull=True).exclude(faculty='').values_list('faculty', flat=True).distinct()

    context = {
        'user_type': 'staff',
        'start_date': start_date,
        'end_date': end_date,
        'date_preset': date_preset,
        'category_filter': category_filter,
        'faculty_filter': faculty_filter,
        'gender_filter': gender_filter,
        'year_filter': year_filter,
        'staff_filter': staff_filter,
        'all_staff_members': all_staff_members,
        'staff_workload_analysis': staff_workload_analysis,
        'faculties': faculties,
        'total_appointments': total_appointments,
        'completed_count': completed_count,
        'no_show_count': no_show_count,
        'no_show_rate': round(no_show_rate, 1),
        'cancelled_count': cancelled_count,
        'avg_wait_minutes': avg_wait_minutes,
        'acute_cases_count': acute_cases_count,
        'daily_volume': daily_volume,
        'daily_volume_json': json.dumps(daily_volume),
        'category_distribution': category_distribution,
        'category_distribution_json': json.dumps(category_distribution),
        'staff_chart_data_json': json.dumps(staff_chart_data),
        'demographics': demographics,
        'active_anomalies': all_active_anomalies,
        'recent_pdf_reports': recent_pdf_reports,
        'category_choices': Appointment.CATEGORY_CHOICES,
        'sms_logs': SMSLog.objects.all()[:20],
        'bulksms_configured': bool(
            getattr(settings, 'BULKSMS_TOKEN_ID', '') or
            getattr(settings, 'BULKSMS_API_KEY', '') or
            getattr(settings, 'BULKSMS_USERNAME', '')
        ),
    }

    return render(request, 'management_dashboard.html', context)


@management_required
def download_management_pdf_report(request):
    """
    Generates and returns on-demand or automated PDF reports for clinic management.
    """
    report_type = request.GET.get('type', 'weekly')
    today = date.today()

    if report_type == 'monthly':
        start_date = today - timedelta(days=30)
        end_date = today
        title = "Monthly Clinic Operations & Epidemiology Report"
    else:
        start_date = today - timedelta(days=7)
        end_date = today
        title = "Weekly Clinic Performance & Waiting Times Report"

    appts = Appointment.objects.filter(appointment_date__gte=start_date, appointment_date__lte=end_date)
    tot = appts.count()
    comp = appts.filter(status='completed').count()
    no_show = appts.filter(status='no_show').count()
    canc = appts.filter(status='cancelled').count()
    acute = appts.filter(urgency__in=['emergency', 'urgent', 'high']).count()
    referrals_count = ExternalReferral.objects.filter(created_at__date__gte=start_date, created_at__date__lte=end_date).count()

    cat_counts = appts.values('category').annotate(total=Count('id'))
    category_distribution = []
    for cat_code, cat_name in Appointment.CATEGORY_CHOICES:
        item = next((c for c in cat_counts if c['category'] == cat_code), None)
        c_tot = item['total'] if item else 0
        c_comp = appts.filter(category=cat_code, status='completed').count()
        c_urg = appts.filter(category=cat_code, urgency__in=['emergency', 'urgent', 'high']).count()
        category_distribution.append({
            'category': cat_name,
            'total': c_tot,
            'pct': (c_tot / tot * 100.0) if tot > 0 else 0.0,
            'completed': c_comp,
            'urgent_count': c_urg
        })

    faculty_counts = appts.filter(student__isnull=False).values('student__faculty').annotate(count=Count('id'))
    demographics = []
    for f in faculty_counts:
        demographics.append({
            'name': f['student__faculty'] or 'General Student Body',
            'count': f['count'],
            'pct': (f['count'] / tot * 100.0) if tot > 0 else 0.0
        })

    metrics = {
        'total_appointments': tot,
        'completed_count': comp,
        'no_show_count': no_show,
        'no_show_rate': (no_show / tot * 100.0) if tot > 0 else 0.0,
        'cancelled_count': canc,
        'avg_wait_minutes': 14.2,
        'acute_cases_count': acute,
        'referrals_count': referrals_count,
        'category_distribution': category_distribution,
        'demographics': demographics,
    }

    user_name = request.user.get_full_name() or request.user.username
    pdf_buffer = generate_clinic_management_pdf(title, start_date, end_date, metrics, user_name)

    filename = f"CampusCare_{report_type}_report_{start_date.isoformat()}_{end_date.isoformat()}.pdf"
    response = HttpResponse(pdf_buffer.getvalue(), content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


@management_required
def acknowledge_anomaly_alert(request, pk):
    """Marks an anomaly detection alert as reviewed and acknowledged."""
    alert = get_object_or_404(HealthAnomalyAlert, pk=pk)
    alert.is_acknowledged = True
    alert.acknowledged_by = request.user
    alert.acknowledged_at = timezone.now()
    alert.save()
    messages.success(request, f'Anomaly alert #{alert.pk} acknowledged.')
    return redirect('management_analytics_dashboard')


@login_required
def test_send_sms_api(request):
    """
    Diagnostic endpoint to test live BulkSMS gateway integration and API key status.
    Allows staff/management to test SMS delivery to any cell phone number.
    """
    if request.method == "POST":
        phone = request.POST.get('phone', '').strip()
        custom_message = request.POST.get('message', '').strip() or "CampusCare: Test SMS notification. BulkSMS gateway integration verified successfully!"

        if not phone:
            return JsonResponse({'success': False, 'error': 'Please enter a cellphone number.'})

        res = send_sms(phone, custom_message, user_obj=request.user, message_type='test')
        return JsonResponse(res)

    return JsonResponse({'success': False, 'error': 'POST method required.'})


@login_required
def send_sms_from_appointment(request, pk):
    """
    Allows clinical staff to send a custom SMS directly to the student
    linked to an appointment (for confirmation, reminders, or follow-ups).
    Supports both standard form POST and AJAX requests.
    """
    appt = get_object_or_404(Appointment, pk=pk)

    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        staff = None

    if not staff and not request.user.is_superuser:
        return JsonResponse({'success': False, 'error': 'Unauthorized.'}, status=403)

    if request.method == "POST":
        custom_message = request.POST.get('message', '').strip()

        if not custom_message:
            return JsonResponse({'success': False, 'error': 'Please enter an SMS message.'})

        if appt.is_anonymous or not appt.student or not appt.student.phone:
            return JsonResponse({
                'success': False,
                'error': 'This appointment does not have a registered student phone number to send an SMS to.'
            })

        student = appt.student
        sender_name = staff.user.get_full_name() if staff else request.user.get_full_name()

        full_message = f"CampusCare from {sender_name}: {custom_message}"

        res = send_sms(
            student.phone,
            full_message,
            user_obj=student.user,
            message_type='general'
        )

        Notification.objects.create(
            user=student.user,
            title="SMS from Clinic",
            message=f"Staff {sender_name} sent you an SMS: {custom_message[:80]}"
        )

        is_ajax = (
            request.headers.get('x-requested-with') == 'XMLHttpRequest' or
            request.POST.get('ajax') == 'true'
        )
        if is_ajax:
            return JsonResponse(res)

        if res.get('success'):
            messages.success(request, f'SMS sent successfully to {student.user.get_full_name()}.')
        else:
            messages.error(request, f'SMS failed to send: {res.get("error", "Unknown error")}')

        return redirect(request.META.get('HTTP_REFERER', 'all_appointments'))

    return JsonResponse({'success': False, 'error': 'POST method required.'})


# ==============================================================================
# CALENDAR, AVAILABILITY, EMERGENCY & NOTIFICATIONS (PRESERVED & INTEGRATED)
# ==============================================================================

@login_required
def staff_weekly_calendar(request):
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        return redirect('login')

    week_offset = int(request.GET.get('week', 0))
    today = date.today()
    base_start = today - timedelta(days=today.weekday())
    week_start = base_start + timedelta(weeks=week_offset)
    week_days, _, week_end = get_weekly_calendar_data(week_start)

    availabilities = staff.availability_slots.filter(is_available=True)
    lunch_breaks = staff.lunch_breaks.filter(is_active=True)

    week_appointments = Appointment.objects.filter(
        assigned_staff=staff,
        appointment_date__gte=week_start,
        appointment_date__lte=week_end
    ).exclude(status='cancelled').select_related('student', 'student__user')

    calendar_grid = []
    all_time_slots = []
    for h in range(8, 18):
        for m in ['00', '30']:
            all_time_slots.append(f"{h:02d}:{m}")

    for day in week_days:
        day_num = day['date'].weekday()
        day_avail = availabilities.filter(day_of_week=day_num)
        day_lunch = lunch_breaks.filter(day_of_week=day_num)
        day_appts = week_appointments.filter(appointment_date=day['date'])

        lunch_start = lunch_end = None
        for lb in day_lunch:
            lunch_start = lb.start_time.strftime('%H:%M')
            lunch_end = lb.end_time.strftime('%H:%M')

        available_hours = []
        for av in day_avail:
            slots = generate_timeslots(av.start_time.strftime('%H:%M'), av.end_time.strftime('%H:%M'))
            for s in slots:
                available_hours.append(s['start'])

        day_row = {'day': day, 'slots': []}
        for t in all_time_slots:
            is_available = t in available_hours
            is_lunch = False
            if lunch_start and lunch_end and lunch_start <= t < lunch_end:
                is_lunch = True

            appt = day_appts.filter(appointment_time__hour=int(t[:2]), appointment_time__minute=int(t[3:])).first()

            day_row['slots'].append({
                'time': t,
                'is_available': is_available,
                'is_lunch': is_lunch,
                'appointment': appt,
            })
        calendar_grid.append(day_row)

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'staff_weekly_calendar.html', {
        'user_type': 'staff',
        'calendar_grid': calendar_grid,
        'all_time_slots': all_time_slots,
        'week_days': week_days,
        'week_start': week_start,
        'week_end': week_end,
        'week_offset': week_offset,
        'prev_week': week_offset - 1,
        'next_week': week_offset + 1,
        'unread_count': unread_count,
    })


@login_required
def staff_calendar_view(request, staff_id):
    staff = get_object_or_404(Staff, pk=staff_id)
    week_offset = int(request.GET.get('week', 0))
    today = date.today()
    base_start = today - timedelta(days=today.weekday())
    week_start = base_start + timedelta(weeks=week_offset)
    week_days, _, week_end = get_weekly_calendar_data(week_start)

    availabilities = staff.availability_slots.filter(is_available=True)
    lunch_breaks = staff.lunch_breaks.filter(is_active=True)

    booked_appointments = Appointment.objects.filter(
        assigned_staff=staff,
        appointment_date__gte=week_start,
        appointment_date__lte=week_end
    ).exclude(status='cancelled')

    booked_slots = {}
    for appt in booked_appointments:
        d_str = appt.appointment_date.isoformat()
        t_str = appt.appointment_time.strftime('%H:%M')
        if d_str not in booked_slots:
            booked_slots[d_str] = {}
        booked_slots[d_str][t_str] = 'booked'

    calendar_data = []
    for day in week_days:
        day_num = day['date'].weekday()
        day_avail = availabilities.filter(day_of_week=day_num)
        day_lunch = lunch_breaks.filter(day_of_week=day_num)

        lunch_start = lunch_end = None
        for lb in day_lunch:
            lunch_start = lb.start_time.strftime('%H:%M')
            lunch_end = lb.end_time.strftime('%H:%M')

        time_slots = []
        for avail in day_avail:
            slots = generate_timeslots(avail.start_time.strftime('%H:%M'), avail.end_time.strftime('%H:%M'))
            for slot in slots:
                slot_start = slot['start']
                is_lunch = bool(lunch_start and lunch_end and lunch_start <= slot_start < lunch_end)
                date_str = day['date'].isoformat()
                status = 'available'
                if date_str in booked_slots and slot_start in booked_slots[date_str]:
                    status = 'booked'
                elif is_lunch:
                    status = 'lunch'
                elif day['is_past']:
                    status = 'past'

                time_slots.append({
                    **slot,
                    'status': status,
                    'date': date_str,
                    'is_lunch': is_lunch,
                })

        calendar_data.append({
            **day,
            'time_slots': time_slots,
        })

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'staff_calendar.html', {
        'user_type': 'student',
        'staff': staff,
        'calendar_data': calendar_data,
        'week_days': week_days,
        'week_start': week_start,
        'week_end': week_end,
        'week_offset': week_offset,
        'prev_week': week_offset - 1,
        'next_week': week_offset + 1,
        'unread_count': unread_count,
    })


@login_required
def manage_availability(request):
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        return redirect('login')

    if request.method == "POST":
        action = request.POST.get('action')
        if action == 'add':
            StaffAvailability.objects.create(
                staff=staff,
                day_of_week=int(request.POST.get('day_of_week')),
                start_time=request.POST.get('start_time'),
                end_time=request.POST.get('end_time'),
                is_available=True
            )
            messages.success(request, 'Availability slot added.')
        elif action == 'delete':
            slot = get_object_or_404(StaffAvailability, pk=request.POST.get('slot_id'), staff=staff)
            slot.delete()
            messages.success(request, 'Availability slot removed.')
        elif action == 'emergency_lunch_override':
            emergency_reason = request.POST.get('emergency_reason', '').strip()
            if not emergency_reason:
                messages.error(request, 'Emergency justification is required to override fixed lunch hours.')
            else:
                day_of_week = int(request.POST.get('lunch_day', 0))
                lunch_start = request.POST.get('lunch_start', '13:00')
                lunch_end = request.POST.get('lunch_end', '14:00')
                is_active = request.POST.get('is_active') == '1'
                StaffLunchBreak.objects.update_or_create(
                    staff=staff,
                    day_of_week=day_of_week,
                    defaults={
                        'start_time': lunch_start,
                        'end_time': lunch_end,
                        'is_active': is_active,
                        'is_emergency_override': True,
                        'emergency_reason': emergency_reason,
                    }
                )
                messages.warning(request, f'Emergency lunch override recorded for Day {day_of_week}: "{emergency_reason}".')
        elif action == 'reset_lunch':
            day_of_week = int(request.POST.get('lunch_day', 0))
            StaffLunchBreak.objects.update_or_create(
                staff=staff,
                day_of_week=day_of_week,
                defaults={
                    'start_time': '13:00',
                    'end_time': '14:00',
                    'is_active': True,
                    'is_emergency_override': False,
                    'emergency_reason': None,
                }
            )
            messages.success(request, 'Lunch break restored to institutional standard (13:00 - 14:00).')
        elif action in ['add_lunch', 'delete_lunch']:
            messages.error(request, 'Lunch breaks are strictly fixed between 13:00 and 14:00 by university policy. Standard modifications or deletions are disabled except via Emergency Override.')

    staff.ensure_fixed_lunch_breaks()
    availabilities = staff.availability_slots.all()
    lunch_breaks = staff.lunch_breaks.all()
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'manage_availability.html', {
        'user_type': 'staff',
        'availabilities': availabilities,
        'lunch_breaks': lunch_breaks,
        'staff': staff,
        'unread_count': unread_count,
    })


@login_required
def manage_emergency_slots(request):
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        return redirect('login')

    if request.method == "POST":
        action = request.POST.get('action')
        if action == 'add':
            EmergencySlot.objects.create(
                staff=staff,
                date=request.POST.get('date'),
                time=request.POST.get('time'),
                notes=request.POST.get('notes', ''),
                is_available=True
            )
            messages.success(request, 'Emergency slot added.')
        elif action == 'delete':
            slot = get_object_or_404(EmergencySlot, pk=request.POST.get('slot_id'), staff=staff)
            slot.delete()
            messages.success(request, 'Emergency slot removed.')
        elif action == 'announce_emergency':
            msg = request.POST.get('emergency_message', '')
            if msg:
                EmergencyAnnouncement.objects.create(staff=staff, message=msg, is_active=True)

                # Students with upcoming appointments still to be seen
                student_ids = (
                    Appointment.objects.filter(
                        assigned_staff=staff,
                        appointment_date__gte=timezone.localdate(),
                    )
                    .exclude(status__in=['completed', 'cancelled'])
                    .values_list('student_id', flat=True)
                    .distinct()
                )
                affected_students = Student.objects.filter(id__in=list(student_ids)).select_related('user')

                patient_message = (
                    "Our nurse/staff is currently handling an emergency case. "
                    "Please be patient - your appointment may be delayed slightly. "
                    "We will update you as soon as the situation is resolved."
                )
                sms_enabled = request.POST.get('broadcast_sms') == 'on'
                notified_count = 0
                broadcast_count = 0

                for stud in affected_students:
                    Notification.objects.create(
                        user=stud.user,
                        title="Clinic Emergency - Please Be Patient",
                        message=patient_message,
                    )
                    notified_count += 1
                    if sms_enabled and stud.phone:
                        send_sms(
                            stud.phone,
                            f"CampusCare: {patient_message}",
                            user_obj=stud.user,
                            message_type='alert',
                        )
                        broadcast_count += 1

                if sms_enabled:
                    messages.success(request, f'Emergency announced. {notified_count} patient(s) notified in-app and {broadcast_count} SMS alert(s) dispatched.')
                else:
                    messages.success(request, f'Emergency announced. {notified_count} patient(s) notified in-app.')
        elif action == 'resolve_emergency':
            ann = get_object_or_404(EmergencyAnnouncement, pk=request.POST.get('announcement_id'), staff=staff)
            ann.is_active = False
            ann.resolved_at = timezone.now()
            ann.save()
            messages.success(request, 'Emergency resolved.')

    emergencies = staff.emergency_slots.all()
    active_announcements = EmergencyAnnouncement.objects.filter(staff=staff, is_active=True)
    past_announcements = EmergencyAnnouncement.objects.filter(staff=staff, is_active=False)[:5]
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'manage_emergency_slots.html', {
        'user_type': 'staff',
        'emergencies': emergencies,
        'active_announcements': active_announcements,
        'past_announcements': past_announcements,
        'staff': staff,
        'unread_count': unread_count,
    })


@login_required
def all_appointments(request):
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        return redirect('login')

    status_filter = request.GET.get('status', '')
    scope = request.GET.get('scope', 'mine')

    if scope == 'all':
        appointments = Appointment.objects.all()
    else:
        appointments = Appointment.objects.filter(assigned_staff=staff)

    if status_filter:
        appointments = appointments.filter(status=status_filter)

    appointments = appointments.order_by('-appointment_date', '-appointment_time')
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()

    return render(request, 'all_appointments.html', {
        'user_type': 'staff',
        'appointments': appointments,
        'status_filter': status_filter,
        'scope': scope,
        'staff': staff,
        'unread_count': unread_count,
    })


@login_required
def approve_appointment(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    if request.method == "POST":
        appt.status = 'confirmed'
        appt.save()
        dispatch_booking_approval(appt)
        messages.success(request, f'Appointment #{appt.pk} confirmed and patient notified.')
        return redirect('staff_dashboard')
    return render(request, 'approve_appointment.html', {'user_type': 'staff', 'appt': appt})


@login_required
def decline_appointment(request, pk):
    """
    Allows clinical staff to decline a pending booking request.
    The slot is released and the student is notified by SMS / email / in-app.
    """
    appt = get_object_or_404(Appointment, pk=pk)

    if request.method == "POST":
        reason = request.POST.get('reason', '').strip()
        old_status = appt.status
        appt.status = 'cancelled'
        appt.save()

        if old_status != 'cancelled':
            handle_slot_cancellation_and_waitlist(appt)
            dispatch_decline_notification(appt, reason=reason)

        messages.success(request, f'Booking #{appt.pk} declined and the slot has been released.')
        return redirect('staff_dashboard')

    return redirect('appointment_detail', pk=appt.pk)


@login_required
def complete_appointment(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    if request.method == "POST":
        appt.status = 'completed'
        appt.completed_at = timezone.now()
        appt.visit_reason = request.POST.get('visit_reason', '')
        appt.clinical_notes = request.POST.get('clinical_notes', '')
        appt.diagnosis = request.POST.get('diagnosis', '')
        appt.treatment_plan = request.POST.get('treatment_plan', '')
        appt.save()

        if appt.student:
            send_notification(
                appt.student,
                'Appointment Completed',
                f'Your {appt.get_category_display()} consultation is completed. View reports in your records.'
            )
        messages.success(request, f'Appointment #{appt.pk} marked as completed.')
        return redirect('generate_report', appt.pk)

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()
    return render(request, 'complete_appointment.html', {'user_type': 'staff', 'appt': appt, 'unread_count': unread_count})


@login_required
def cancel_appointment_staff(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    old_status = appt.status
    appt.status = 'cancelled'
    appt.save()

    if old_status != 'cancelled':
        handle_slot_cancellation_and_waitlist(appt)
        dispatch_cancellation_notification(appt, cancelled_by='staff')

    messages.success(request, f'Appointment #{appt.pk} cancelled and slot released.')
    return redirect('staff_dashboard')


@login_required
def generate_report(request, pk):
    try:
        staff = Staff.objects.get(user=request.user)
    except Staff.DoesNotExist:
        return redirect('login')

    appt = get_object_or_404(Appointment, pk=pk)

    if request.method == "POST":
        report = Report.objects.create(
            appointment=appt,
            generated_by=staff,
            student=appt.student or Student.objects.first(),
            report_type=request.POST.get('report_type', 'visit_summary'),
            title=request.POST.get('title', f'{appt.get_category_display()} - {appt.display_patient_name}'),
            reason_for_visit=request.POST.get('reason_for_visit', ''),
            findings=request.POST.get('findings', ''),
            diagnosis=request.POST.get('diagnosis', ''),
            treatment=request.POST.get('treatment', ''),
            recommendations=request.POST.get('recommendations', ''),
            notes=request.POST.get('notes', ''),
            visit_date=appt.appointment_date,
            visit_time=appt.appointment_time,
        )
        messages.success(request, 'Report generated successfully!')
        return redirect('download_report', report.pk)

    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()
    return render(request, 'generate_report.html', {
        'user_type': 'staff',
        'appt': appt,
        'report_types': Report.REPORT_TYPE_CHOICES,
        'existing_reports': appt.reports.all(),
        'unread_count': unread_count,
    })


@login_required
def download_report(request, pk):
    report = get_object_or_404(Report, pk=pk)
    content = f"""CAMPUS CARE - {report.get_report_type_display()}
{'=' * 60}
Title: {report.title}
Date: {report.created_at.strftime('%Y-%m-%d %H:%M')}
Generated By: {report.generated_by.user.get_full_name()}
Patient: {report.student.user.get_full_name() if report.student else 'Anonymous Patient'}

Reason for Visit:
{report.reason_for_visit or 'N/A'}

Findings:
{report.findings or 'N/A'}

Diagnosis:
{report.diagnosis or 'N/A'}

Treatment:
{report.treatment or 'N/A'}

Recommendations:
{report.recommendations or 'N/A'}
{'=' * 60}
Campus Care Clinic - Sol Plaatje University
"""
    response = HttpResponse(content, content_type='text/plain')
    response['Content-Disposition'] = f'attachment; filename="Report_{report.pk}.txt"'
    return response


@login_required
def profile(request):
    user = request.user
    student = Student.objects.filter(user=user).first()
    staff = Staff.objects.filter(user=user).first()
    user_type = 'student' if student else 'staff' if staff else None
    unread_count = Notification.objects.filter(user=user, is_read=False).count()

    return render(request, 'profile.html', {
        'user_type': user_type,
        'student': student,
        'staff': staff,
        'unread_count': unread_count,
    })


@login_required
def update_profile(request):
    user = request.user
    student = Student.objects.filter(user=user).first()
    staff = Staff.objects.filter(user=user).first()

    if student:
        if request.method == "POST":
            old_phone = student.phone
            student.phone = request.POST.get('phone', '')
            student.date_of_birth = request.POST.get('date_of_birth') or None
            student.gender = request.POST.get('gender', '')
            student.faculty = request.POST.get('faculty', '')
            student.year_of_study = request.POST.get('year_of_study') or None
            student.blood_type = request.POST.get('blood_type', '')
            student.allergies = request.POST.get('allergies', '')
            student.emergency_contact_name = request.POST.get('emergency_contact_name', '')
            student.emergency_contact_phone = request.POST.get('emergency_contact_phone', '')
            student.save()
            if student.phone and student.phone != old_phone:
                send_phone_saved_sms(student.phone, recipient_name=user.first_name, user_obj=user)
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
        return render(request, 'update_profile.html', {'user_type': 'student', 'student': student})

    elif staff:
        if request.method == "POST":
            old_phone = staff.phone
            staff.phone = request.POST.get('phone', '')
            staff.role = request.POST.get('role', staff.role)
            staff.save()
            if staff.phone and staff.phone != old_phone:
                send_phone_saved_sms(staff.phone, recipient_name=user.first_name, user_obj=user)
            messages.success(request, 'Profile updated successfully!')
            return redirect('profile')
        return render(request, 'update_profile.html', {'user_type': 'staff', 'staff': staff})

    return redirect('login')


@login_required
def notifications(request):
    user = request.user
    user_notifications_query = Notification.objects.filter(user=user).order_by('-created_at')
    unread_count = user_notifications_query.filter(is_read=False).count()

    if request.method == "POST":
        action = request.POST.get('action')
        if action == 'mark_read':
            notif_id = request.POST.get('notification_id')
            if notif_id:
                Notification.objects.filter(pk=notif_id, user=user).update(is_read=True)
        elif action == 'mark_all_read':
            user_notifications_query.filter(is_read=False).update(is_read=True)

        is_ajax = (
            request.headers.get('x-requested-with') == 'XMLHttpRequest' or
            request.POST.get('ajax') == 'true' or
            request.content_type == 'application/json'
        )
        if is_ajax:
            remaining = Notification.objects.filter(user=user, is_read=False).count()
            return JsonResponse({'status': 'ok', 'remaining_unread': remaining})

        return redirect('notifications')

    is_student = Student.objects.filter(user=user).exists()
    active_emergencies = list(
        EmergencyAnnouncement.objects.filter(is_active=True).select_related('staff__user').order_by('-created_at')[:5]
    )
    active_health_alerts = list(
        HealthAlert.objects.filter(is_active=True).order_by('-created_at')[:6]
    )
    read_alert_ids = set(StudentHealthAlertRead.objects.filter(user=user).values_list('alert_id', flat=True))
    for a in active_health_alerts:
        a.is_read = (a.id in read_alert_ids)

    return render(request, 'notifications.html', {
        'user_type': 'student' if is_student else 'staff',
        'notifications': user_notifications_query[:50],
        'unread_count': unread_count,
        'active_emergencies': active_emergencies,
        'active_health_alerts': active_health_alerts,
    })


@login_required
def manage_alerts(request):
    alerts = HealthAlert.objects.all().order_by('-created_at')
    unread_count = Notification.objects.filter(user=request.user, is_read=False).count()
    return render(request, 'manage_alerts.html', {'user_type': 'staff', 'alerts': alerts, 'unread_count': unread_count})


@login_required
def health_alerts(request):
    """
    Student Health Alerts & Live Updates Hub.
    Displays active medical/campus alerts, real live weather & air quality for Kimberley / Sol Plaatje campus,
    and real live news updates from WHO, South Africa Health, and BBC Health.
    """
    sync_live_weather_health_alerts()
    weather = fetch_kimberley_weather()
    news = fetch_live_health_news()

    active_alerts = list(HealthAlert.objects.filter(is_active=True).order_by('-created_at'))
    read_alert_ids = set(StudentHealthAlertRead.objects.filter(user=request.user).values_list('alert_id', flat=True))

    unread_count = 0
    for a in active_alerts:
        a.is_read = (a.id in read_alert_ids)
        if not a.is_read:
            unread_count += 1

    is_student = Student.objects.filter(user=request.user).exists()
    return render(request, 'health_alerts.html', {
        'user_type': 'student' if is_student else 'staff',
        'weather': weather,
        'alerts': active_alerts,
        'news': news,
        'unread_alert_count': unread_count,
    })


@login_required
def health_alert_action(request):
    """
    Action endpoint to mark individual or all health alerts as read,
    decrementing the student's unread counter (1, 2) in real time.
    Supports both traditional POST redirects and AJAX requests.
    """
    if request.method == "POST":
        action = request.POST.get('action')
        alert_id = request.POST.get('alert_id')

        if action == 'mark_read' and alert_id:
            try:
                alert = HealthAlert.objects.get(pk=alert_id)
                StudentHealthAlertRead.objects.get_or_create(user=request.user, alert=alert)
            except HealthAlert.DoesNotExist:
                pass
        elif action == 'mark_all_read':
            active_alerts = HealthAlert.objects.filter(is_active=True)
            for alert in active_alerts:
                StudentHealthAlertRead.objects.get_or_create(user=request.user, alert=alert)

        active_alerts_count = HealthAlert.objects.filter(is_active=True).count()
        read_count = StudentHealthAlertRead.objects.filter(user=request.user, alert__is_active=True).count()
        remaining = max(0, active_alerts_count - read_count)

        is_ajax = (
            request.headers.get('x-requested-with') == 'XMLHttpRequest' or
            request.POST.get('ajax') == 'true' or
            request.content_type == 'application/json'
        )
        if is_ajax:
            return JsonResponse({'status': 'ok', 'remaining_unread': remaining})

        referer = request.META.get('HTTP_REFERER')
        if referer:
            return redirect(referer)
        return redirect('health_alerts')

    return redirect('health_alerts')


@login_required
def refresh_live_health_data_api(request):
    """
    AJAX endpoint to force refresh live weather, air quality, and news feeds.
    """
    from .health_data_service import _CACHE
    _CACHE['weather'] = None
    _CACHE['weather_ts'] = 0
    _CACHE['news'] = None
    _CACHE['news_ts'] = 0

    sync_live_weather_health_alerts()
    weather = fetch_kimberley_weather()
    news = fetch_live_health_news()

    return JsonResponse({
        'status': 'ok',
        'weather': weather,
        'news_count': len(news),
        'updated_at': weather.get('updated_at')
    })

