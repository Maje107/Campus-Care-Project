from django.utils import timezone
from django.db.models import Case, When, Value, IntegerField
from .models import WaitlistEntry, Appointment, Notification
from .notifications import dispatch_waitlist_offer_notification


def handle_slot_cancellation_and_waitlist(cancelled_appointment):
    """
    Called whenever an appointment is cancelled (via web, reminder, or staff).
    Releases the slot and automatically reassigns it to the next waitlisted
    student in strict order of their priority level:
    Emergency > Urgent > Routine, then earliest created_at.
    """
    staff_member = cancelled_appointment.assigned_staff
    appt_date = cancelled_appointment.appointment_date
    appt_time = cancelled_appointment.appointment_time

    # Find eligible waitlisted candidates for this date and staff (or any staff)
    waitlist_qs = WaitlistEntry.objects.filter(
        preferred_date=appt_date,
        status='waiting'
    )

    if staff_member:
        waitlist_qs = waitlist_qs.filter(
            models_staff_match(staff_member)
        )

    # Annotate priority order: Emergency (1) -> Urgent (2) -> Routine (3)
    waitlist_qs = waitlist_qs.annotate(
        priority_rank=Case(
            When(urgency='emergency', then=Value(1)),
            When(urgency='urgent', then=Value(2)),
            When(urgency='routine', then=Value(3)),
            When(urgency='high', then=Value(2)),
            When(urgency='medium', then=Value(2)),
            default=Value(3),
            output_field=IntegerField()
        )
    ).order_by('priority_rank', 'created_at')

    next_candidate = waitlist_qs.first()

    if not next_candidate:
        return None

    # Reallocate slot to this candidate
    next_candidate.status = 'booked'
    next_candidate.offered_slot_time = appt_time
    next_candidate.offered_at = timezone.now()
    next_candidate.save()

    # Automatically create confirmed appointment for waitlisted student
    new_appointment = Appointment.objects.create(
        student=next_candidate.student,
        assigned_staff=staff_member,
        category=next_candidate.category,
        urgency=next_candidate.urgency,
        appointment_date=appt_date,
        appointment_time=appt_time,
        symptoms=next_candidate.symptoms,
        intake_duration=next_candidate.intake_duration,
        intake_pain_scale=next_candidate.intake_pain_scale,
        intake_red_flags=next_candidate.intake_red_flags,
        is_anonymous=bool(next_candidate.anonymous_code),
        anonymous_code=next_candidate.anonymous_code,
        anonymous_token=next_candidate.anonymous_token,
        status='confirmed'
    )

    # Dispatch notification to the waitlisted student
    dispatch_waitlist_offer_notification(next_candidate, appt_date, appt_time, staff_member)

    # Notify staff
    if staff_member:
        patient_label = next_candidate.display_name
        Notification.objects.create(
            user=staff_member.user,
            title="Slot Reassigned from Waitlist",
            message=(
                f"The released slot on {appt_date} at {appt_time} has been automatically allocated "
                f"to waitlisted patient {patient_label} (Priority: {next_candidate.urgency.capitalize()})."
            )
        )

    return new_appointment


def models_staff_match(staff_member):
    from django.db.models import Q
    return Q(preferred_staff=staff_member) | Q(preferred_staff__isnull=True)
