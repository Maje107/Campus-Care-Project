import os
import re
import requests
from dotenv import load_dotenv

load_dotenv()

SEVEN_API_KEY = os.getenv("SEVEN_API_KEY", "").strip()
SEVEN_SENDER_ID = os.getenv("SEVEN_SENDER_ID", "CampusCare")
SEVEN_MODE = os.getenv("SEVEN_MODE", "mock").lower()
BULKSMS_MODE = os.getenv("BULKSMS_MODE", "mock").lower()
DEFAULT_COUNTRY_CODE = os.getenv("DEFAULT_COUNTRY_CODE", "27")

SEVEN_SMS_URL = "https://gateway.seven.io/api/sms"


def is_valid_south_african_phone(phone_number):
    """
    Verifies that a phone number is a valid South African number.
    Accepts:
      - Local format: 10 digits starting with 0 followed by 1-9 (e.g. 071 234 5678, 082 123 4567, 060 123 4567)
      - International format: +27 followed by 9 digits (e.g. +27715441437)
      - International prefix 27: 27 followed by 9 digits (total 11 digits, e.g. 27715441437)
      - International prefix 0027: 0027 followed by 9 digits (total 13 digits)
    Strictly rejects all other country codes (e.g. +1, +44, +234, etc.) and invalid digit lengths.
    """
    if not phone_number:
        return False

    raw = str(phone_number).strip()
    # Remove any whitespace, dashes, parentheses, or dots
    cleaned = re.sub(r'[\s\-\(\)\.]', '', raw)

    # If it starts with a plus, it MUST be South African (+27)
    if cleaned.startswith('+'):
        if not cleaned.startswith('+27'):
            return False
        sa_digits = cleaned[3:]
        return bool(re.match(r'^[1-9]\d{8}$', sa_digits))

    # If it starts with 00 (international dialing prefix)
    if cleaned.startswith('00'):
        if not cleaned.startswith('0027'):
            return False
        sa_digits = cleaned[4:]
        return bool(re.match(r'^[1-9]\d{8}$', sa_digits))

    # If it starts with 27 (11 digits total)
    if cleaned.startswith('27') and len(cleaned) == 11:
        sa_digits = cleaned[2:]
        return bool(re.match(r'^[1-9]\d{8}$', sa_digits))

    # Local format: exactly 10 digits starting with 0 followed by 1-9
    if cleaned.startswith('0') and len(cleaned) == 10:
        return bool(re.match(r'^0[1-9]\d{8}$', cleaned))

    return False


def normalize_phone_number(phone_number):
    """
    Convert common South African phone formats to international format (+27XXXXXXXXX).
    """
    if not phone_number:
        return ""

    raw = str(phone_number).strip()
    digits = "".join(c for c in raw if c.isdigit())

    if digits.startswith("0027") and len(digits) == 13:
        digits = digits[2:]  # 27...
    elif digits.startswith("0") and len(digits) == 10:
        digits = "27" + digits[1:]
    elif digits.startswith("27") and len(digits) == 11:
        pass
    elif len(digits) == 9:
        digits = "27" + digits

    return f"+{digits}"


def validate_and_normalize_sa_phone(phone_number):
    """
    Verifies that the phone number is a valid South African number and returns
    its normalized +27XXXXXXXXX format.
    Raises ValueError if verification fails.
    """
    if not is_valid_south_african_phone(phone_number):
        raise ValueError(
            f"Number verification failed: '{phone_number}' is not a valid South African cellphone number. "
            f"Only South African numbers (e.g., 071 234 5678 or +27 71 234 5678) are accepted."
        )
    return normalize_phone_number(phone_number)


def send_sms(phone_number, message, user_obj=None, message_type='general', *args, **kwargs):
    """
    Verifies that the phone number is South African, normalizes it,
    delivers the SMS via Seven.io or BulkSMS (or mock mode), and logs in SMSLog.
    Returns a dict: {'success': bool, 'error' / 'message': str, 'recipient': str}
    """
    # 1. South African Number Verification
    if not is_valid_south_african_phone(phone_number):
        err_msg = (
            f"Number verification failed: '{phone_number}' is not a valid South African cellphone number. "
            f"Only South African numbers (e.g. 071 234 5678 or +27 71 234 5678) are accepted."
        )
        print(f"[SMS BLOCKED - SA VERIFICATION FAILED] {err_msg}")
        try:
            from .models import SMSLog
            SMSLog.objects.create(
                recipient_phone=str(phone_number)[:30],
                recipient_user=user_obj,
                message_type=message_type,
                message=message,
                status='failed',
                error_message=err_msg
            )
        except Exception:
            pass
        return {'success': False, 'error': err_msg}

    recipient = normalize_phone_number(phone_number)

    # 2. Check Mock Mode or Missing API Key
    # Only use mock if the mode is explicitly 'mock' OR if the API key is missing.
    is_mock = (SEVEN_MODE == "mock" or not SEVEN_API_KEY)

    if is_mock:
        print(f"\n[MOCK SMS VERIFIED SA DISPATCH]")
        print(f"To: {recipient} (South Africa verified)")
        print(f"Message: {message}")
        print("-" * 50)

        try:
            from .models import SMSLog
            SMSLog.objects.create(
                recipient_phone=recipient,
                recipient_user=user_obj,
                message_type=message_type,
                message=message,
                status='simulated',
                response_payload={'status': 'simulated', 'verified_sa': True}
            )
        except Exception as e:
            print("Failed to save SMSLog:", e)

        return {
            'success': True,
            'message': 'Simulated SMS dispatch (Mock Mode - South Africa Verified).',
            'recipient': recipient,
            'status': 'simulated'
        }

    # 3. Live Gateway Dispatch
    if not recipient or not message:
        return {'success': False, 'error': 'Recipient or message is empty.'}

    headers = {
        "X-Api-Key": SEVEN_API_KEY,
        "Accept": "application/json",
    }

    data = {
        "to": recipient,
        "text": message,
        "from": SEVEN_SENDER_ID,
        "json": "1"  # Ensure we get JSON response
    }

    try:
        response = requests.post(
            SEVEN_SMS_URL,
            headers=headers,
            data=data,
            timeout=15,
        )
        response.raise_for_status()
        result = response.json()

        # Seven.io always returns HTTP 200 with a top-level 'success': '100' even when
        # an individual message fails. The real per-message result is in result['messages'].
        message_result = {}
        if isinstance(result.get("messages"), list) and result["messages"]:
            message_result = result["messages"][0]

        delivered = bool(message_result.get("success")) if message_result else False
        gateway_error = message_result.get("error_text") or message_result.get("error")
        if not delivered:
            print("Seven.io rejected the SMS:", gateway_error or result)
            try:
                from .models import SMSLog
                SMSLog.objects.create(
                    recipient_phone=recipient,
                    recipient_user=user_obj,
                    message_type=message_type,
                    message=message,
                    status='failed',
                    response_payload=result,
                    error_message=str(gateway_error or result)
                )
            except Exception:
                pass
            return {
                'success': False,
                'error': f"Gateway rejected SMS: {gateway_error or result}",
                'recipient': recipient,
                'status': 'failed'
            }

        success_code = str(result.get("success", ""))
        if success_code == "100" or response.status_code == 200:
            print(f"SMS accepted by Seven.io for {recipient}.")
            try:
                from .models import SMSLog
                SMSLog.objects.create(
                    recipient_phone=recipient,
                    recipient_user=user_obj,
                    message_type=message_type,
                    message=message,
                    status='sent',
                    response_payload=result
                )
            except Exception as e:
                print("Failed to save SMSLog:", e)

            return {
                'success': True,
                'message': 'SMS dispatched successfully via Seven.io.',
                'recipient': recipient,
                'status': 'sent'
            }

        print("Seven.io rejected the SMS:", result)
        try:
            from .models import SMSLog
            SMSLog.objects.create(
                recipient_phone=recipient,
                recipient_user=user_obj,
                message_type=message_type,
                message=message,
                status='failed',
                response_payload=result,
                error_message=str(result)
            )
        except Exception:
            pass

        return {'success': False, 'error': f"Gateway error: {result}"}

    except Exception as error:
        print("SMS delivery error:", error)
        try:
            from .models import SMSLog
            SMSLog.objects.create(
                recipient_phone=recipient,
                recipient_user=user_obj,
                message_type=message_type,
                message=message,
                status='failed',
                error_message=str(error)
            )
        except Exception:
            pass

        return {'success': False, 'error': str(error)}


def send_phone_saved_sms(phone_number, *args, **kwargs):
    """Notify a user after their South African phone number has been verified and saved."""
    message = "Campus Care: Your South African phone number has been verified and linked successfully."
    return send_sms(phone_number, message, *args, **kwargs)
