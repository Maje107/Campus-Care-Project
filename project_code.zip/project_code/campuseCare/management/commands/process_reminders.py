from django.core.management.base import BaseCommand
from campuseCare.reminder_engine import process_all_reminders


class Command(BaseCommand):
    help = 'Processes upcoming appointments and dispatches 1h, 30m, and 15m actionable reminders'

    def handle(self, *args, **options):
        self.stdout.write("Checking upcoming appointments for reminder windows (1h, 30m, 15m)...")
        results = process_all_reminders()
        self.stdout.write(
            self.style.SUCCESS(
                f"Reminders processed successfully: "
                f"1h: {results['1h']}, 30m: {results['30m']}, 15m: {results['15m']}"
            )
        )
