import uuid
from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    student_number = models.CharField(max_length=20, unique=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=20, blank=True, null=True)

    faculty = models.CharField(max_length=100, blank=True, null=True)
    year_of_study = models.IntegerField(blank=True, null=True)

    blood_type = models.CharField(max_length=5, blank=True, null=True)
    allergies = models.TextField(blank=True, null=True)

    emergency_contact_name = models.CharField(max_length=100, blank=True, null=True)
    emergency_contact_phone = models.CharField(max_length=15, blank=True, null=True)

    def save(self, *args, **kwargs):
        if self.phone:
            from .sms_service import normalize_phone_number
            self.phone = normalize_phone_number(self.phone)
        if self.emergency_contact_phone:
            from .sms_service import normalize_phone_number
            self.emergency_contact_phone = normalize_phone_number(self.emergency_contact_phone)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.student_number})"


class Staff(models.Model):
    ROLE_CHOICES = [
        ('nurse', 'Nurse'),
        ('counsellor', 'Counsellor'),
        ('social_worker', 'Social Worker'),
        ('doctor', 'Doctor'),
        ('management', 'Clinic Management'),
        ('other', 'Other'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)

    staff_id = models.CharField(max_length=20, unique=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    role = models.CharField(max_length=50, choices=ROLE_CHOICES, blank=True, null=True)

    @property
    def is_clinical(self):
        return self.role in ['nurse', 'counsellor', 'social_worker', 'doctor']

    @property
    def is_management(self):
        return self.role in ['management'] or self.user.is_superuser

    def ensure_fixed_lunch_breaks(self):
        """Ensures the staff member has fixed 13:00 - 14:00 lunch breaks for Monday to Friday."""
        from datetime import time
        for day in range(5):
            StaffLunchBreak.objects.get_or_create(
                staff=self,
                day_of_week=day,
                defaults={
                    'start_time': time(13, 0),
                    'end_time': time(14, 0),
                    'is_active': True,
                    'is_emergency_override': False,
                }
            )

    def save(self, *args, **kwargs):
        if self.phone:
            from .sms_service import normalize_phone_number
            self.phone = normalize_phone_number(self.phone)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.staff_id})"


class StaffAvailability(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='availability_slots')

    day_of_week = models.IntegerField(choices=[
        (0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'),
        (3, 'Thursday'), (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday')
    ])
    start_time = models.TimeField()
    end_time = models.TimeField()
    is_available = models.BooleanField(default=True)
    is_lunch_break = models.BooleanField(default=False)

    class Meta:
        ordering = ['day_of_week', 'start_time']

    def __str__(self):
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        label = 'Lunch' if self.is_lunch_break else 'Available'
        return f"{self.staff.user.get_full_name()} - {days[self.day_of_week]} {self.start_time}-{self.end_time} ({label})"


class StaffLunchBreak(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='lunch_breaks')
    day_of_week = models.IntegerField(choices=[
        (0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'),
        (3, 'Thursday'), (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday')
    ])
    start_time = models.TimeField(default='13:00')
    end_time = models.TimeField(default='14:00')
    is_active = models.BooleanField(default=True)
    is_emergency_override = models.BooleanField(default=False)
    emergency_reason = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        ordering = ['day_of_week', 'start_time']
        unique_together = ['staff', 'day_of_week']

    def __str__(self):
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        override_txt = " [EMERGENCY OVERRIDE]" if self.is_emergency_override else ""
        return f"{self.staff.user.get_full_name()} Lunch - {days[self.day_of_week]} {self.start_time}-{self.end_time}{override_txt}"


class EmergencySlot(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='emergency_slots')

    date = models.DateField()
    time = models.TimeField()
    is_available = models.BooleanField(default=True)
    notes = models.TextField(blank=True, null=True)

    class Meta:
        ordering = ['date', 'time']

    def __str__(self):
        return f"Emergency: {self.date} {self.time}"


class EmergencyAnnouncement(models.Model):
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='emergency_announcements')
    message = models.TextField()
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f"Emergency by {self.staff} - {'Active' if self.is_active else 'Resolved'}"


class Appointment(models.Model):

    CATEGORY_CHOICES = [
        ('general', 'General Consultation'),
        ('mental', 'Mental Health'),
        ('sexual', 'Reproductive & Sexual Health'),
        ('injury', 'Injury'),
        ('other', 'Other'),
    ]

    URGENCY_CHOICES = [
        ('emergency', 'Emergency'),
        ('urgent', 'Urgent'),
        ('routine', 'Routine'),
        ('high', 'High (Urgent)'),
        ('medium', 'Medium (Urgent)'),
        ('low', 'Low (Routine)'),
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('rescheduled', 'Rescheduled'),
        ('no_show', 'No-Show'),
    ]

    # Student link is null=True to strictly guarantee that anonymous bookings
    # have no FK, join table, or reversible reference to a real student ID.
    student = models.ForeignKey(Student, on_delete=models.SET_NULL, null=True, blank=True, related_name='appointments')
    assigned_staff = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_appointments')

    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    urgency = models.CharField(max_length=20, choices=URGENCY_CHOICES, default='routine')

    appointment_date = models.DateField()
    appointment_time = models.TimeField()

    symptoms = models.TextField()

    # Digital Intake Form fields
    intake_duration = models.CharField(max_length=50, blank=True, null=True)
    intake_pain_scale = models.IntegerField(default=0, blank=True, null=True)
    intake_red_flags = models.JSONField(default=list, blank=True)
    triage_notes = models.TextField(blank=True, null=True)
    triage_timestamp = models.DateTimeField(null=True, blank=True)

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='confirmed')

    # Anonymous booking fields
    is_anonymous = models.BooleanField(default=False)
    anonymous_code = models.CharField(max_length=50, blank=True, null=True, unique=True)
    anonymous_token = models.UUIDField(default=uuid.uuid4, editable=False)

    # Direct action token for reminder emails/SMS (confirm, cancel, reschedule)
    action_token = models.UUIDField(default=uuid.uuid4, editable=False)

    # Reminders tracking
    reminder_1h_sent = models.BooleanField(default=False)
    reminder_30m_sent = models.BooleanField(default=False)
    reminder_15m_sent = models.BooleanField(default=False)

    # Clinical outcomes & consultation notes
    visit_reason = models.TextField(blank=True, null=True)
    clinical_notes = models.TextField(blank=True, null=True)
    diagnosis = models.TextField(blank=True, null=True)
    treatment_plan = models.TextField(blank=True, null=True)

    # Operational metrics & timing
    checked_in_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['appointment_date', 'appointment_time']
        constraints = [
            models.UniqueConstraint(
                fields=['assigned_staff', 'appointment_date', 'appointment_time'],
                condition=~models.Q(status='cancelled'),
                name='unique_active_staff_slot'
            )
        ]

    @property
    def display_patient_name(self):
        if self.is_anonymous or not self.student:
            return f"Anonymous ({self.anonymous_code or 'Patient'})"
        return self.student.user.get_full_name()

    @property
    def normalized_urgency(self):
        val = (self.urgency or '').lower()
        if val in ['emergency']:
            return 'emergency'
        if val in ['urgent', 'high', 'medium']:
            return 'urgent'
        return 'routine'

    @property
    def normalized_urgency_display(self):
        return self.normalized_urgency.capitalize()

    @property
    def priority_sort_key(self):
        mapping = {'emergency': 1, 'urgent': 2, 'routine': 3}
        return mapping.get(self.normalized_urgency, 3)

    @property
    def wait_time_minutes(self):
        """Calculates waiting time in minutes from scheduled or check-in to completion."""
        if self.completed_at:
            from datetime import datetime
            from django.utils import timezone
            scheduled_dt = datetime.combine(self.appointment_date, self.appointment_time)
            base_time = self.checked_in_at or scheduled_dt

            if timezone.is_aware(self.completed_at):
                if timezone.is_naive(base_time):
                    base_time = timezone.make_aware(base_time)
            else:
                if timezone.is_aware(base_time):
                    base_time = timezone.make_naive(base_time)

            diff = (self.completed_at - base_time).total_seconds() / 60.0
            return max(0.0, round(diff, 1))
        return 0.0

    @property
    def pain_severity_display(self):
        val = self.intake_pain_scale
        if val is None or val == 0:
            return "0 - None"
        elif val <= 3:
            return f"{val} - Mild"
        elif val <= 6:
            return f"{val} - Moderate"
        elif val <= 8:
            return f"{val} - Severe"
        else:
            return f"{val} - Extreme / Critical"

    @property
    def pain_severity_badge_class(self):
        val = self.intake_pain_scale or 0
        if val == 0:
            return "bg-secondary text-white"
        elif val <= 3:
            return "bg-success text-white"
        elif val <= 6:
            return "bg-warning text-dark"
        elif val <= 8:
            return "bg-danger text-white"
        else:
            return "bg-dark text-white"

    def __str__(self):
        return f"{self.display_patient_name} - {self.category} ({self.status})"


class WaitlistEntry(models.Model):
    STATUS_CHOICES = [
        ('waiting', 'Waiting'),
        ('offered', 'Slot Offered'),
        ('booked', 'Booked & Confirmed'),
        ('cancelled', 'Cancelled'),
        ('expired', 'Expired'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, blank=True, related_name='waitlist_entries')
    anonymous_code = models.CharField(max_length=50, blank=True, null=True)
    anonymous_token = models.UUIDField(default=uuid.uuid4, editable=False)

    category = models.CharField(max_length=20, choices=Appointment.CATEGORY_CHOICES)
    preferred_date = models.DateField()
    preferred_staff = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, related_name='waitlist_requests')

    symptoms = models.TextField()
    intake_duration = models.CharField(max_length=50, blank=True, null=True)
    intake_pain_scale = models.IntegerField(default=0, blank=True, null=True)
    intake_red_flags = models.JSONField(default=list, blank=True)
    urgency = models.CharField(max_length=20, choices=Appointment.URGENCY_CHOICES, default='routine')

    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='waiting')
    offered_slot_time = models.TimeField(null=True, blank=True)
    offered_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-urgency', 'created_at']

    @property
    def display_name(self):
        if self.student:
            return self.student.user.get_full_name()
        return f"Anonymous ({self.anonymous_code or 'Patient'})"

    @property
    def priority_sort_key(self):
        val = (self.urgency or '').lower()
        if val in ['emergency']:
            return 1
        if val in ['urgent', 'high', 'medium']:
            return 2
        return 3

    def __str__(self):
        return f"Waitlist: {self.display_name} - {self.category} ({self.urgency})"


class ExternalReferral(models.Model):
    REFERRAL_STATUS_CHOICES = [
        ('pending', 'Pending Transmission'),
        ('transmitted', 'Transmitted to Facility'),
        ('completed', 'Consultation Completed'),
        ('cancelled', 'Cancelled'),
    ]

    appointment = models.ForeignKey(Appointment, on_delete=models.SET_NULL, null=True, blank=True, related_name='external_referrals')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, null=True, blank=True, related_name='external_referrals')
    referred_by = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='referrals_made')

    service_name = models.CharField(max_length=200)
    service_type = models.CharField(max_length=100)
    urgency = models.CharField(max_length=20, choices=Appointment.URGENCY_CHOICES, default='urgent')
    reason = models.TextField()
    clinical_summary = models.TextField(blank=True, null=True)
    contact_info = models.CharField(max_length=200, blank=True, null=True)
    status = models.CharField(max_length=20, choices=REFERRAL_STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Referral to {self.service_name} ({self.urgency})"


class MedicalRecord(models.Model):
    RECORD_TYPE_CHOICES = [
        ('prescription', 'Prescription'),
        ('lab_result', 'Lab Result'),
        ('referral', 'Referral Letter'),
        ('discharge', 'Discharge Summary'),
        ('vaccination', 'Vaccination Record'),
        ('other', 'Other'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='medical_records')
    uploaded_by_staff = models.ForeignKey(Staff, on_delete=models.SET_NULL, null=True, blank=True, related_name='uploaded_records')

    title = models.CharField(max_length=200)
    record_type = models.CharField(max_length=50, choices=RECORD_TYPE_CHOICES, default='other')
    description = models.TextField(blank=True, null=True)

    record_file = models.FileField(upload_to='medical_records/%Y/%m/%d/', max_length=500)

    diagnosis = models.TextField(blank=True, null=True)
    treatment = models.TextField(blank=True, null=True)
    doctor_name = models.CharField(max_length=100, blank=True, null=True)

    record_date = models.DateField(auto_now_add=True)
    upload_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.student} ({self.record_date})"

    @property
    def filename(self):
        import os
        return os.path.basename(self.record_file.name)

    @property
    def file_extension(self):
        import os
        _, ext = os.path.splitext(self.record_file.name)
        return ext.lower().lstrip('.')


class Report(models.Model):
    REPORT_TYPE_CHOICES = [
        ('visit_summary', 'Visit Summary'),
        ('medical_letter', 'Medical Letter'),
        ('referral', 'Referral Letter'),
        ('sick_note', 'Sick Note'),
        ('other', 'Other'),
    ]

    appointment = models.ForeignKey(Appointment, on_delete=models.CASCADE, related_name='reports')
    generated_by = models.ForeignKey(Staff, on_delete=models.CASCADE, related_name='generated_reports')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='reports')

    report_type = models.CharField(max_length=50, choices=REPORT_TYPE_CHOICES, default='visit_summary')
    title = models.CharField(max_length=200)

    reason_for_visit = models.TextField(blank=True, null=True)
    findings = models.TextField(blank=True, null=True)
    diagnosis = models.TextField(blank=True, null=True)
    treatment = models.TextField(blank=True, null=True)
    recommendations = models.TextField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)

    visit_date = models.DateField()
    visit_time = models.TimeField()

    report_file = models.FileField(upload_to='reports/%Y/%m/%d/', max_length=500, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.student} ({self.visit_date})"


class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')

    title = models.CharField(max_length=100)
    message = models.TextField()

    is_read = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.user}"


class HealthAlert(models.Model):
    SEVERITY_CHOICES = [
        ('info', 'Info'),
        ('warning', 'Warning'),
        ('danger', 'Danger'),
    ]

    CATEGORY_CHOICES = [
        ('weather', 'Weather Advisory'),
        ('air_quality', 'Air Quality & Respiratory'),
        ('outbreak', 'Disease Outbreak'),
        ('campus', 'Campus Clinic Notice'),
        ('general', 'General Health Notice'),
    ]

    title = models.CharField(max_length=150)
    message = models.TextField()
    severity = models.CharField(max_length=10, choices=SEVERITY_CHOICES, default='info')
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='campus')
    source = models.CharField(max_length=100, default='Campus Care Clinic')
    external_link = models.URLField(blank=True, null=True)
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.get_severity_display()}] {self.title}"


class StudentHealthAlertRead(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='read_health_alerts')
    alert = models.ForeignKey(HealthAlert, on_delete=models.CASCADE, related_name='read_receipts')
    read_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'alert']
        ordering = ['-read_at']

    def __str__(self):
        return f"{self.user.username} read alert #{self.alert_id} at {self.read_at}"



class HealthAnomalyAlert(models.Model):
    SEVERITY_CHOICES = [
        ('info', 'Information'),
        ('warning', 'Warning'),
        ('critical', 'Critical Surge'),
    ]

    metric_name = models.CharField(max_length=100)
    category = models.CharField(max_length=50, blank=True, null=True)
    description = models.TextField()
    baseline_rate = models.FloatField(help_text="Expected historical weekly average")
    detected_rate = models.FloatField(help_text="Current observed volume")
    percent_increase = models.FloatField()
    severity = models.CharField(max_length=20, choices=SEVERITY_CHOICES, default='warning')

    is_acknowledged = models.BooleanField(default=False)
    acknowledged_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='acknowledged_anomalies')
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    detected_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-detected_at']

    def __str__(self):
        return f"Anomaly: {self.metric_name} (+{self.percent_increase:.1f}%)"


class ManagementReport(models.Model):
    REPORT_TYPE_CHOICES = [
        ('weekly', 'Weekly Clinic Performance Report'),
        ('monthly', 'Monthly Health Analytics Report'),
        ('custom', 'Custom Clinic Report'),
    ]

    report_type = models.CharField(max_length=20, choices=REPORT_TYPE_CHOICES)
    start_date = models.DateField()
    end_date = models.DateField()
    pdf_file = models.FileField(upload_to='management_reports/%Y/%m/', max_length=500, blank=True, null=True)
    total_appointments = models.IntegerField(default=0)
    no_show_rate = models.FloatField(default=0.0)
    average_wait_time_minutes = models.FloatField(default=0.0)
    metrics_summary = models.JSONField(default=dict, blank=True)

    generated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.get_report_type_display()} ({self.start_date} to {self.end_date})"


class SMSLog(models.Model):
    MESSAGE_TYPE_CHOICES = [
        ('confirmation', 'Booking / Approval Confirmation'),
        ('cancellation', 'Cancellation Notification'),
        ('reminder', 'Actionable Reminder'),
        ('registration', 'Phone Linked / Saved'),
        ('waitlist', 'Waitlist Slot Allocation'),
        ('alert', 'Health Alert / Emergency Announcement'),
        ('test', 'Test SMS Gateway'),
        ('general', 'General Notification'),
    ]

    STATUS_CHOICES = [
        ('sent', 'Sent Successfully'),
        ('simulated', 'Simulated (Mock / Pending Key)'),
        ('failed', 'Failed'),
    ]

    recipient_phone = models.CharField(max_length=30)
    recipient_user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='sms_logs')
    message_type = models.CharField(max_length=30, choices=MESSAGE_TYPE_CHOICES, default='general')
    message = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='sent')
    response_payload = models.JSONField(default=dict, blank=True)
    error_message = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"SMS to {self.recipient_phone} [{self.message_type}] - {self.status}"


class PasswordResetOTP(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='password_reset_otps')
    otp_code = models.CharField(max_length=4)
    phone_number = models.CharField(max_length=30)
    is_verified = models.BooleanField(default=False)
    is_used = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

    class Meta:
        ordering = ['-created_at']

    def is_expired(self):
        from django.utils import timezone
        return timezone.now() > self.expires_at

    def __str__(self):
        status = "Used" if self.is_used else ("Verified" if self.is_verified else "Pending")
        return f"OTP {self.otp_code} for {self.user.username} ({status})"