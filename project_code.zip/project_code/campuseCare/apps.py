from django.apps import AppConfig


class CampusecareConfig(AppConfig):
    name = 'campuseCare'
