import os
import logging
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse
from .models import Notification

logger = logging.getLogger(__name__)


def get_base_url():
    """Returns local domain or base URL for reminder action links."""
    return getattr(settings, 'SITE_BASE_URL', 'http://127.0.0.1:8000')


def send_notification(user_obj, title, message):
    """
    Creates an in-app notification for a User or model with a user attribute.
    """
    if hasattr(user_obj, 'user'):
        target_user = user_obj.user
    else:
        target_user = user_obj
    return Notification.objects.create(
        user=target_user,
        title=title,
        message=message
    )


def format_date_safe(d):
    if isinstance(d, str):
        try:
            from datetime import datetime
            return datetime.strptime(d, '%Y-%m-%d').strftime('%A, %d %B %Y')
        except ValueError:
            return d
    return d.strftime('%A, %d %B %Y')


def format_time_safe(t):
    if isinstance(t, str):
        return t[:5]
    return t.strftime('%H:%M')


def send_sms_notification(phone_number, message, user_obj=None, message_type='general'):
    """
    Delivers an SMS notification via the BulkSMS gateway service and audits it in SMSLog.
    """
    if not phone_number:
        logger.info("[SMS Delivery Skipped] No phone number provided.")
        return False

    from .sms_service import send_sms
    res = send_sms(phone_number, message, user_obj=user_obj, message_type=message_type)
    return res.get('success', False)


def send_email_notification(recipient_email, subject, text_message, html_message=None):
    """
    Sends email notification via Django's mail backend.
    Fails silently in development if SMTP is unconfigured.
    """
    if not recipient_email:
        return False

    from_email = getattr(settings, 'DEFAULT_FROM_EMAIL', 'campuscare@spu.ac.za')
    try:
        send_mail(
            subject=subject,
            message=text_message,
            from_email=from_email,
            recipient_list=[recipient_email],
            html_message=html_message,
            fail_silently=True
        )
        print(f"\n[EMAIL OUTBOUND to {recipient_email}]\nSubject: {subject}\n{text_message}\n" + "-" * 50)
        return True
    except Exception as exc:
        logger.warning(f"Email delivery failed to {recipient_email}: {exc}")
        return False


def dispatch_booking_received(appointment):
    """
    Sends an instant "booking request received" advisory via In-App, Email and SMS
    when a student submits a booking.
    The appointment stays PENDING until a clinical staff member accepts it -
    the "confirmed" SMS is only sent at that point (see dispatch_booking_approval),
    or a decline notice is sent (see dispatch_decline_notification).
    """
    base_url = get_base_url()
    date_str = format_date_safe(appointment.appointment_date)
    time_str = format_time_safe(appointment.appointment_time)
    staff_name = appointment.assigned_staff.user.get_full_name() if appointment.assigned_staff else "Campus Clinic Team"
    category_name = appointment.get_category_display()
    priority_name = appointment.normalized_urgency_display

    action_url = f"{base_url}/appointment/action/{appointment.action_token}/"
    cancel_url = f"{action_url}?action=cancel"

    if appointment.is_anonymous:
        # Anonymous booking received (No PII stored, displayed on screen / session)
        anon_portal_url = f"{base_url}/appointment/anonymous/{appointment.anonymous_token}/"
        print(f"\n[ANONYMOUS BOOKING RECEIVED: {appointment.anonymous_code}]")
        print(f"Time: {date_str} at {time_str} | Staff: {staff_name}")
        print(f"Private Access Link: {anon_portal_url}\n" + "-" * 50)
        return

    student = appointment.student
    if not student:
        return

    user = student.user
    email = user.email
    phone = student.phone

    subject = f"Booking Received: Campus Care - {date_str} at {time_str}"
    
    body = f"""Dear {user.first_name or 'Student'},

Your appointment request has been sent to Campus Care and is now awaiting confirmation from our clinical team.

Booking Details:
- Date: {date_str}
- Time: {time_str}
- Category: {category_name}
- Triage Priority: {priority_name}

You may cancel this request at any time using the link below:
- Cancel Appointment: {cancel_url}

You will receive a confirmation SMS and email as soon as a clinical staff member accepts your booking.
Important: Please remember to arrive at the clinic 15 minutes before your appointment time.

Thank you for choosing Campus Care.
Sol Plaatje University Student Wellness Services
"""

    # 1. In-App Notification
    Notification.objects.create(
        user=user,
        title="Booking Request Sent",
        message=f"Your {category_name} booking for {date_str} at {time_str} has been sent to the clinic. "
                f"You will be notified once a staff member confirms it."
    )

    # 2. Email Delivery
    if email:
        send_email_notification(email, subject, body)

    # 3. SMS Delivery
    sms_body = (
        f"CampusCare: Your booking for {category_name} on {date_str} at {time_str} has been sent to the clinic. "
        f"You will receive a confirmation SMS once it is accepted. Please arrive 15 minutes early."
    )
    if phone:
        send_sms_notification(phone, sms_body, user_obj=user, message_type='confirmation')


def dispatch_booking_approval(appointment):
    """
    Sends automated confirmation via In-App, Email, and SMS when staff explicitly approves an appointment.
    """
    date_str = format_date_safe(appointment.appointment_date)
    time_str = format_time_safe(appointment.appointment_time)
    staff_name = appointment.assigned_staff.user.get_full_name() if appointment.assigned_staff else "Campus Clinic Team"
    category_name = appointment.get_category_display()

    if appointment.is_anonymous or not appointment.student:
        return

    student = appointment.student
    user = student.user
    email = user.email
    phone = student.phone

    # 1. In-App Notification
    Notification.objects.create(
        user=user,
        title="Appointment Confirmed",
        message=f"Your {category_name} appointment on {date_str} at {time_str} has been approved by {staff_name}. "
                f"Please arrive 15 minutes early."
    )

    # 2. Email Delivery
    if email:
        subject = f"Appointment Confirmed: Campus Care - {date_str} at {time_str}"
        body = f"""Dear {user.first_name or 'Student'},

Your {category_name} appointment on {date_str} at {time_str} with {staff_name} has been reviewed and officially confirmed.

Important: Please remember to arrive at the clinic 15 minutes before your appointment time.

Sol Plaatje University Student Wellness Services
"""
        send_email_notification(email, subject, body)

    # 3. SMS Delivery
    sms_body = (
        f"CampusCare: CONFIRMED - your {category_name} appointment on {date_str} at {time_str} with {staff_name}. "
        f"Please remember to arrive 15 minutes early."
    )
    if phone:
        send_sms_notification(phone, sms_body, user_obj=user, message_type='confirmation')


def dispatch_decline_notification(appointment, reason=None):
    """
    Notifies the student that the clinic could not accept their booking request
    (staff declined it), via In-App, Email, and SMS.
    """
    date_str = format_date_safe(appointment.appointment_date)
    time_str = format_time_safe(appointment.appointment_time)
    category_name = appointment.get_category_display()
    staff_name = appointment.assigned_staff.user.get_full_name() if appointment.assigned_staff else "Clinical Staff"

    if appointment.is_anonymous or not appointment.student:
        print(f"\n[ANONYMOUS BOOKING DECLINED: {appointment.anonymous_code}] Slot: {date_str} at {time_str}\n" + "-" * 50)
        return

    student = appointment.student
    user = student.user
    email = user.email
    phone = student.phone

    reason_line = f"\nReason: {reason}" if reason else ""

    # 1. In-App Notification
    Notification.objects.create(
        user=user,
        title="Booking Declined by Clinic",
        message=f"Your {category_name} booking for {date_str} at {time_str} was not accepted by the clinic. "
                f"Please book another slot or contact the clinic."
    )

    # 2. Email Delivery
    if email:
        subject = f"Booking Declined: Campus Care - {date_str} at {time_str}"
        body = f"""Dear {user.first_name or 'Student'},

Unfortunately your {category_name} booking for {date_str} at {time_str} with {staff_name} was not accepted by the clinic.{reason_line}

The reserved slot has been released. Please log in to Campus Care to book an alternative time, or contact the clinic directly for assistance.

Sol Plaatje University Student Wellness Services
"""
        send_email_notification(email, subject, body)

    # 3. SMS Delivery
    sms_body = (
        f"CampusCare: Unfortunately your {category_name} booking on {date_str} at {time_str} was not accepted. "
        f"Please log in to book another slot or contact the clinic."
    )
    if phone:
        send_sms_notification(phone, sms_body, user_obj=user, message_type='cancellation')


def dispatch_cancellation_notification(appointment, cancelled_by="student", reason=None):
    """
    Sends automated cancellation notifications via In-App, Email, and SMS
    whenever an appointment is cancelled by the student or clinical staff.
    """
    base_url = get_base_url()
    date_str = format_date_safe(appointment.appointment_date)
    time_str = format_time_safe(appointment.appointment_time)
    category_name = appointment.get_category_display()
    staff_name = appointment.assigned_staff.user.get_full_name() if appointment.assigned_staff else "Clinical Staff"

    if appointment.is_anonymous:
        print(f"\n[ANONYMOUS APPOINTMENT CANCELLED: {appointment.anonymous_code}] Slot: {date_str} at {time_str}\n" + "-" * 50)
        return

    student = appointment.student
    if not student:
        return

    user = student.user
    email = user.email
    phone = student.phone

    if cancelled_by == "staff":
        title = "Appointment Cancelled by Clinic"
        student_msg = f"Your {category_name} appointment on {date_str} at {time_str} with {staff_name} was cancelled by clinic staff."
        sms_body = (
            f"CampusCare: Your {category_name} appt on {date_str} at {time_str} was cancelled by clinic staff. "
            f"Please log into your student portal to book an alternate slot."
        )
    else:
        title = "Appointment Cancelled"
        student_msg = f"Your {category_name} appointment on {date_str} at {time_str} has been cancelled successfully."
        sms_body = f"CampusCare: Your {category_name} appt on {date_str} at {time_str} has been cancelled successfully."

    # 1. In-App Notification to Student
    Notification.objects.create(
        user=user,
        title=title,
        message=student_msg
    )

    # 2. Email Delivery to Student
    if email:
        subject = f"Appointment Cancelled: Campus Care - {date_str}"
        body = f"""Dear {user.first_name or 'Student'},

{student_msg}

The previously reserved slot has been released back to available slots for other students.
If you require care, please log into Campus Care to schedule a new consultation.

Sol Plaatje University Student Wellness Services
"""
        send_email_notification(email, subject, body)

    # 3. SMS Delivery to Student
    if phone:
        send_sms_notification(phone, sms_body, user_obj=user, message_type='cancellation')

    # 4. Notify Assigned Staff if Student initiated cancellation
    if cancelled_by == "student" and appointment.assigned_staff and appointment.assigned_staff.user:
        staff_user = appointment.assigned_staff.user
        Notification.objects.create(
            user=staff_user,
            title="Appointment Cancelled by Patient",
            message=f"Patient {user.get_full_name()} cancelled their {category_name} appointment for {date_str} at {time_str}. Slot released to waitlist."
        )
        if appointment.assigned_staff.phone:
            staff_sms = (
                f"CampusCare Staff Alert: Patient {user.get_full_name()} cancelled appt on {date_str} at {time_str}. "
                f"Slot automatically released."
            )
            send_sms_notification(appointment.assigned_staff.phone, staff_sms, user_obj=staff_user, message_type='cancellation')


def dispatch_actionable_reminder(appointment, interval_label):
    """
    Sends automated appointment reminders at three intervals: 1h, 30m, 15m.
    Includes direct action tokens to Confirm, Reschedule, or Cancel directly from the notification.
    """
    base_url = get_base_url()
    date_str = format_date_safe(appointment.appointment_date)
    time_str = format_time_safe(appointment.appointment_time)
    staff_name = appointment.assigned_staff.user.get_full_name() if appointment.assigned_staff else "Clinical Staff"
    category_name = appointment.get_category_display()

    action_url = f"{base_url}/appointment/action/{appointment.action_token}/"
    confirm_url = f"{action_url}?action=confirm"
    reschedule_url = f"{action_url}?action=reschedule"
    cancel_url = f"{action_url}?action=cancel"

    if appointment.is_anonymous:
        # Anonymous appointment reminder logging
        print(f"\n[ANON REMINDER ({interval_label})] Code: {appointment.anonymous_code} | Slot: {date_str} {time_str}")
        return

    student = appointment.student
    if not student:
        return

    user = student.user
    email = user.email
    phone = student.phone

    subject = f"Appointment Reminder ({interval_label}): Campus Care Today at {time_str}"
    body = f"""Hello {user.first_name or 'Student'},

This is a reminder that your {category_name} consultation with {staff_name} is scheduled for TODAY at {time_str} ({interval_label} from now).

Please select an action directly below:
[Confirm Attendance]: {confirm_url}
[Reschedule Slot]: {reschedule_url}
[Cancel Appointment]: {cancel_url}

Please note: If you cannot make it, cancelling as early as possible automatically releases the slot to students waiting for care.

Campus Care Clinic - Sol Plaatje University
"""

    sms_body = (
        f"CampusCare Reminder ({interval_label}): Appt today at {time_str} with {staff_name}. "
        f"Confirm: {confirm_url} | Reschedule: {reschedule_url} | Cancel: {cancel_url}"
    )

    # In-app notification
    Notification.objects.create(
        user=user,
        title=f"Reminder ({interval_label}): Appointment at {time_str}",
        message=f"Upcoming {category_name} appointment at {time_str} today. Please confirm or cancel if your plans changed."
    )

    # Email
    if email:
        send_email_notification(email, subject, body)

    # SMS
    if phone:
        send_sms_notification(phone, sms_body, user_obj=user, message_type='reminder')


def dispatch_waitlist_offer_notification(waitlist_entry, date_val, time_val, staff_obj):
    """
    Notifies a waitlisted student that a released slot is offered to them.
    """
    base_url = get_base_url()
    date_str = date_val.strftime('%A, %d %B %Y')
    time_str = time_val.strftime('%H:%M')
    staff_name = staff_obj.user.get_full_name() if staff_obj else "Clinic Staff"

    if waitlist_entry.student:
        user = waitlist_entry.student.user
        email = user.email
        phone = waitlist_entry.student.phone

        subject = f"Good News! Released Slot Available at Campus Care - {date_str} at {time_str}"
        body = f"""Hello {user.first_name or 'Student'},

A slot has just opened up due to a cancellation for {date_str} at {time_str} with {staff_name}.
Because of your priority on the clinic waiting list, this slot has been automatically reserved for you!

Please log into Campus Care or contact the clinic if you need any assistance.

Campus Care Clinic
"""
        Notification.objects.create(
            user=user,
            title="Waitlist Slot Opened Up!",
            message=f"A slot opened up on {date_str} at {time_str} with {staff_name} and has been allocated to you."
        )

        if email:
            send_email_notification(email, subject, body)
        if phone:
            sms = f"CampusCare: Slot opened for {date_str} at {time_str} with {staff_name}. It has been allocated to you!"
            send_sms_notification(phone, sms, user_obj=user, message_type='waitlist')


def notify_user_with_sms(user_obj, title, message, send_sms=True, message_type='general'):
    """
    Helper to send an in-app notification and automatically dispatch an SMS if user has a registered cell phone.
    """
    if hasattr(user_obj, 'user'):
        target_user = user_obj.user
    else:
        target_user = user_obj

    notif = Notification.objects.create(
        user=target_user,
        title=title,
        message=message
    )

    if send_sms:
        phone = None
        if hasattr(target_user, 'student') and target_user.student.phone:
            phone = target_user.student.phone
        elif hasattr(target_user, 'staff') and target_user.staff.phone:
            phone = target_user.staff.phone

        if phone:
            sms_body = f"CampusCare: {title} - {message}"
            send_sms_notification(phone, sms_body, user_obj=target_user, message_type=message_type)

    return notif
