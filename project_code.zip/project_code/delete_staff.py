import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project_code.settings')
django.setup()

from django.contrib.auth.models import User
from campuseCare.models import Staff, StaffAvailability, StaffLunchBreak, EmergencySlot, EmergencyAnnouncement, Appointment

def delete_all_staff():
    print("Beginning deletion of all staff members...")
    
    # 1. Clear assigned staff from appointments so bookings are not lost
    unassigned_count = Appointment.objects.filter(assigned_staff__isnull=False).update(assigned_staff=None)
    print(f"Updated {unassigned_count} appointments to unassigned practitioner.")

    # 2. Collect staff user accounts
    staff_qs = Staff.objects.all()
    staff_count = staff_qs.count()
    user_ids = list(staff_qs.values_list('user_id', flat=True))

    # 3. Delete dependent availability, lunch breaks, and emergency slots
    StaffAvailability.objects.all().delete()
    StaffLunchBreak.objects.all().delete()
    EmergencySlot.objects.all().delete()
    EmergencyAnnouncement.objects.all().delete()

    # 4. Delete staff profiles
    staff_qs.delete()
    print(f"Successfully deleted {staff_count} Staff profile records.")

    # 5. Delete staff user accounts (except superuser admin if needed, or all staff users)
    staff_users = User.objects.filter(id__in=user_ids).exclude(is_superuser=True)
    deleted_users_count, _ = staff_users.delete()
    print(f"Successfully deleted {deleted_users_count} associated staff User account(s).")

    print("\nAll staff members have been completely deleted from the database.")

if __name__ == '__main__':
    delete_all_staff()
