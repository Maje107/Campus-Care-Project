from datetime import datetime, date, timedelta
from django.utils import timezone
from .models import Appointment
from .notifications import dispatch_actionable_reminder


def process_all_reminders():
    """
    Checks all upcoming confirmed and pending appointments for today
    and sends automated actionable reminders at:
    - 1 hour before (60m)
    - 30 minutes before (30m)
    - 15 minutes before (15m)
    """
    now = timezone.localtime() if timezone.is_aware(timezone.now()) else datetime.now()
    today = now.date()

    appointments = Appointment.objects.filter(
        appointment_date=today,
        status__in=['confirmed', 'pending']
    )

    sent_counts = {'1h': 0, '30m': 0, '15m': 0}

    for appt in appointments:
        appt_dt = datetime.combine(appt.appointment_date, appt.appointment_time)
        if timezone.is_aware(now):
            appt_dt = timezone.make_aware(appt_dt, timezone.get_current_timezone())

        diff_seconds = (appt_dt - now).total_seconds()
        diff_minutes = diff_seconds / 60.0

        # Only process future appointments for today
        if diff_minutes < 0:
            continue

        # 1. 1 Hour Reminder Window (50 to 70 minutes before)
        if 50 <= diff_minutes <= 70 and not appt.reminder_1h_sent:
            dispatch_actionable_reminder(appt, "1 Hour")
            appt.reminder_1h_sent = True
            appt.save(update_fields=['reminder_1h_sent'])
            sent_counts['1h'] += 1

        # 2. 30 Minutes Reminder Window (22 to 38 minutes before)
        elif 22 <= diff_minutes <= 38 and not appt.reminder_30m_sent:
            dispatch_actionable_reminder(appt, "30 Minutes")
            appt.reminder_30m_sent = True
            appt.save(update_fields=['reminder_30m_sent'])
            sent_counts['30m'] += 1

        # 3. 15 Minutes Reminder Window (8 to 20 minutes before)
        elif 8 <= diff_minutes <= 20 and not appt.reminder_15m_sent:
            dispatch_actionable_reminder(appt, "15 Minutes")
            appt.reminder_15m_sent = True
            appt.save(update_fields=['reminder_15m_sent'])
            sent_counts['15m'] += 1

    return sent_counts


def trigger_test_reminder(appointment, interval_label="1 Hour"):
    """Manually sends a reminder with action tokens for verification/testing."""
    dispatch_actionable_reminder(appointment, interval_label)
    if interval_label == "1 Hour":
        appointment.reminder_1h_sent = True
    elif interval_label == "30 Minutes":
        appointment.reminder_30m_sent = True
    elif interval_label == "15 Minutes":
        appointment.reminder_15m_sent = True
    appointment.save()
