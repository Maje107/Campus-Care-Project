from datetime import date, timedelta
from django.utils import timezone
from django.db.models import Count
from django.contrib.auth.models import User
from .models import Appointment, ExternalReferral, HealthAnomalyAlert, Staff, Notification
from .notifications import send_email_notification


def run_health_anomaly_detection(reference_date=None):
    """
    Analyzes clinic trend volumes (e.g. 7-day rolling window) against historical
    baseline (previous 30-day weekly average).
    Detects sudden spikes (e.g. mental health bookings or referrals) and triggers
    automatic alerts to designated clinic management personnel.
    """
    if reference_date is None:
        reference_date = date.today()

    recent_start = reference_date - timedelta(days=7)
    baseline_start = reference_date - timedelta(days=37)
    baseline_end = recent_start

    generated_alerts = []

    # 1. Check Appointment Categories (Mental Health, Sexual Health, Injuries, etc.)
    for cat_code, cat_label in Appointment.CATEGORY_CHOICES:
        # Recent 7-day count
        recent_count = Appointment.objects.filter(
            category=cat_code,
            appointment_date__gte=recent_start,
            appointment_date__lte=reference_date
        ).exclude(status='cancelled').count()

        # Baseline count over 30 days -> weekly rate (count / 30 * 7)
        baseline_raw = Appointment.objects.filter(
            category=cat_code,
            appointment_date__gte=baseline_start,
            appointment_date__lt=baseline_end
        ).exclude(status='cancelled').count()
        baseline_weekly_avg = round((baseline_raw / 30.0) * 7.0, 1)

        # Baseline threshold (minimum 1.0 for comparison)
        effective_baseline = max(baseline_weekly_avg, 1.0)
        percent_increase = ((recent_count - effective_baseline) / effective_baseline) * 100.0

        # Anomaly condition: >= 50% surge and at least 3 cases
        if percent_increase >= 50.0 and recent_count >= 3:
            metric_id = f"spike_{cat_code}_consultations"
            
            # Avoid duplicate active alerts within the last 48 hours
            recent_alert = HealthAnomalyAlert.objects.filter(
                metric_name=metric_id,
                detected_at__gte=timezone.now() - timedelta(days=2)
            ).first()

            if not recent_alert:
                severity = 'critical' if percent_increase >= 100.0 else 'warning'
                desc = (
                    f"Epidemiological Trend Surge: {cat_label} consultations increased by {percent_increase:.1f}% "
                    f"over the past 7 days ({recent_count} observed vs {baseline_weekly_avg:.1f} expected weekly baseline)."
                )
                alert = HealthAnomalyAlert.objects.create(
                    metric_name=metric_id,
                    category=cat_code,
                    description=desc,
                    baseline_rate=baseline_weekly_avg,
                    detected_rate=float(recent_count),
                    percent_increase=round(percent_increase, 1),
                    severity=severity
                )
                dispatch_management_anomaly_alert(alert)
                generated_alerts.append(alert)

    # 2. Check Mental Health & Crisis External Referrals
    recent_referrals = ExternalReferral.objects.filter(
        created_at__date__gte=recent_start,
        created_at__date__lte=reference_date
    ).count()

    baseline_referrals_raw = ExternalReferral.objects.filter(
        created_at__date__gte=baseline_start,
        created_at__date__lt=baseline_end
    ).count()
    baseline_referrals_weekly = round((baseline_referrals_raw / 30.0) * 7.0, 1)
    effective_ref_baseline = max(baseline_referrals_weekly, 1.0)
    ref_increase = ((recent_referrals - effective_ref_baseline) / effective_ref_baseline) * 100.0

    if ref_increase >= 50.0 and recent_referrals >= 2:
        metric_id = "spike_external_specialist_referrals"
        recent_alert = HealthAnomalyAlert.objects.filter(
            metric_name=metric_id,
            detected_at__gte=timezone.now() - timedelta(days=2)
        ).first()

        if not recent_alert:
            desc = (
                f"External Referrals Spike: Clinic referrals to external hospitals/specialists surged by "
                f"{ref_increase:.1f}% ({recent_referrals} in last 7 days vs {baseline_referrals_weekly:.1f} weekly baseline)."
            )
            alert = HealthAnomalyAlert.objects.create(
                metric_name=metric_id,
                category='mental',
                description=desc,
                baseline_rate=baseline_referrals_weekly,
                detected_rate=float(recent_referrals),
                percent_increase=round(ref_increase, 1),
                severity='critical'
            )
            dispatch_management_anomaly_alert(alert)
            generated_alerts.append(alert)

    return generated_alerts


def dispatch_management_anomaly_alert(alert):
    """Notifies designated clinic management and admin personnel."""
    # Find management staff and superusers
    managers = Staff.objects.filter(role='management')
    superusers = User.objects.filter(is_superuser=True)

    recipient_users = set([m.user for m in managers] + list(superusers))

    title = f"HEALTH TREND ANOMALY DETECTED: {alert.metric_name.replace('_', ' ').title()}"
    msg = (
        f"Automated Anomaly Alert [{alert.get_severity_display().upper()}]:\n\n"
        f"{alert.description}\n"
        f"Baseline: {alert.baseline_rate} / week | Detected: {alert.detected_rate} | Increase: +{alert.percent_increase}%\n\n"
        f"Please inspect the Management Analytics Dashboard for demographic and clinical details."
    )

    for user in recipient_users:
        Notification.objects.create(
            user=user,
            title=title[:100],
            message=msg
        )
        if user.email:
            send_email_notification(user.email, title, msg)
