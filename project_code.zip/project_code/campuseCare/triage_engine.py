import re
from datetime import datetime
from django.utils import timezone


EMERGENCY_RED_FLAGS = {
    'chest_pain': 'Severe chest pain, tightness, or pressure radiating to arm/jaw',
    'breathing_difficulty': 'Severe difficulty breathing or respiratory distress',
    'suicidal_thoughts': 'Active thoughts of suicide, self-harm, or severe psychiatric crisis',
    'severe_bleeding': 'Heavy, uncontrollable bleeding or acute deep wound',
    'loss_of_consciousness': 'Fainting, seizure, or sudden loss of consciousness',
    'anaphylaxis': 'Severe allergic reaction with swelling of lips/tongue/throat',
    'confusion_speech': 'Sudden confusion, slurred speech, or facial weakness',
}

URGENT_FLAGS = {
    'acute_injury_deformity': 'Suspected bone fracture, dislocation, or inability to bear weight',
    'sexual_pep_72h': 'Potential HIV/STI exposure within the last 72 hours requiring PEP',
    'high_fever': 'High fever (> 39°C / 102°F) accompanied by chills or stiff neck',
    'severe_panic_crisis': 'Acute severe anxiety or panic attack without self-harm intent',
    'severe_vomiting_dehydration': 'Persistent vomiting or inability to keep fluids down for 24h',
}

EMERGENCY_KEYWORDS = [
    r'\bsuicid', r'\bkill\s+myself\b', r'\bend\s+my\s+life\b', r'\bhang\s+myself\b',
    r'\bchest\s+pain\b', r'\bheart\s+attack\b', r'\bcan(\'t|not)\s+breath',
    r'\basphyxi', r'\bunconscious\b', r'\bprofuse\s+bleed', r'\bhemorrhag',
    r'\banaphylax', r'\bseizure\b', r'\bstroke\b', r'\boverdose\b'
]

URGENT_KEYWORDS = [
    r'\bfractur', r'\bbroken\s+bone\b', r'\bdislocat', r'\bpost[\s-]exposure\b',
    r'\bpep\b', r'\bsexual\s+assault\b', r'\brape\b', r'\bhigh\s+fever\b',
    r'\bpanic\s+attack\b', r'\bdeep\s+cut\b', r'\bstitch', r'\bsprain\b',
    r'\bsevere\s+pain\b', r'\bappendi'
]


def evaluate_triage(category, symptoms_text, duration_str='', pain_scale=0, red_flags=None):
    """
    Evaluates digital intake data against clinical triage criteria.
    Assigns one of three priority levels: Emergency, Urgent, Routine.
    """
    if red_flags is None:
        red_flags = []
    elif isinstance(red_flags, str):
        red_flags = [red_flags]

    text = (symptoms_text or '').lower()
    reasons = []
    priority = 'routine'

    try:
        pain_val = int(pain_scale or 0)
    except (ValueError, TypeError):
        pain_val = 0

    # 1. Check for Emergency Red Flags
    emergency_detected = False
    for flag in red_flags:
        if flag in EMERGENCY_RED_FLAGS:
            emergency_detected = True
            reasons.append(f"Emergency flag present: {EMERGENCY_RED_FLAGS[flag]}")

    # Check for Emergency Keyword Triggers
    if not emergency_detected:
        for pattern in EMERGENCY_KEYWORDS:
            if re.search(pattern, text, re.IGNORECASE):
                emergency_detected = True
                reasons.append(f"Emergency keyword pattern identified in symptoms text: '{pattern}'")
                break

    if emergency_detected:
        priority = 'emergency'
        triage_score = 1
        triage_notes = (
            f"CLINICAL TRIAGE: EMERGENCY (Level 1). Immediate medical intervention required. "
            f"Reasons: {'; '.join(reasons)}."
        )
        return {
            'priority': 'emergency',
            'triage_score': triage_score,
            'reasons': reasons,
            'triage_notes': triage_notes,
            'is_emergency': True,
        }

    # 2. Check for Urgent Criteria
    urgent_detected = False
    for flag in red_flags:
        if flag in URGENT_FLAGS:
            urgent_detected = True
            reasons.append(f"Urgent symptom flag present: {URGENT_FLAGS[flag]}")

    if pain_val >= 7:
        urgent_detected = True
        reasons.append(f"Severe self-reported pain score: {pain_val}/10")

    if not urgent_detected:
        for pattern in URGENT_KEYWORDS:
            if re.search(pattern, text, re.IGNORECASE):
                urgent_detected = True
                reasons.append(f"Urgent clinical pattern identified: '{pattern}'")
                break

    # Category-specific urgency rules
    if category == 'injury' and pain_val >= 5:
        urgent_detected = True
        reasons.append(f"Acute injury reported with moderate-to-severe pain ({pain_val}/10)")

    if category in ['mental', 'sexual'] and (duration_str == '<24h' or pain_val >= 6):
        urgent_detected = True
        reasons.append("Acute onset sensitive consultation (<24h onset / high distress)")

    if urgent_detected:
        priority = 'urgent'
        triage_score = 2
        triage_notes = (
            f"CLINICAL TRIAGE: URGENT (Level 2). Priority queue elevation assigned. "
            f"Reasons: {'; '.join(reasons)}."
        )
        return {
            'priority': 'urgent',
            'triage_score': triage_score,
            'reasons': reasons,
            'triage_notes': triage_notes,
            'is_emergency': False,
        }

    # 3. Default Routine
    reasons.append("Standard outpatient presentation with no acute red-flags identified")
    if pain_val > 0:
        reasons.append(f"Pain level noted at {pain_val}/10")
    triage_notes = f"CLINICAL TRIAGE: ROUTINE (Level 3). Reasons: {'; '.join(reasons)}."

    return {
        'priority': 'routine',
        'triage_score': 3,
        'reasons': reasons,
        'triage_notes': triage_notes,
        'is_emergency': False,
    }


def trigger_emergency_clinical_alert(appointment):
    """
    Dispatches immediate alerts to all on-duty and clinical staff
    when an Emergency triage priority appointment is created.
    """
    from .models import Staff, Notification, HealthAlert

    patient_desc = appointment.display_patient_name
    category_desc = appointment.get_category_display()
    time_desc = f"{appointment.appointment_date} at {appointment.appointment_time}"

    alert_title = f"EMERGENCY CLINICAL ALERT: {category_desc}"
    alert_msg = (
        f"CRITICAL: Emergency triage case booked for {time_desc}. "
        f"Patient: {patient_desc}. Symptoms: {appointment.symptoms[:200]}. "
        f"Triage Notes: {appointment.triage_notes or 'Emergency priority assigned.'}"
    )

    # Broadcast to all clinical staff members
    clinical_staff = Staff.objects.filter(role__in=['nurse', 'doctor', 'counsellor', 'social_worker', 'management'])
    for staff in clinical_staff:
        Notification.objects.create(
            user=staff.user,
            title=alert_title,
            message=alert_msg,
        )

    # Create active clinic-wide HealthAlert for top banner visibility
    HealthAlert.objects.create(
        title=f"Clinical Emergency: {category_desc}",
        message=f"Case #{appointment.pk} ({patient_desc}) classified as EMERGENCY at {timezone.now().strftime('%H:%M')}.",
        severity='danger'
    )
