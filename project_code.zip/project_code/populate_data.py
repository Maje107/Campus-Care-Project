import os
import django
from datetime import date, time, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project_code.settings')
django.setup()

from django.contrib.auth.models import User
from campuseCare.models import (
    Student, Staff, StaffAvailability, StaffLunchBreak,
    Appointment, MedicalRecord, Notification, HealthAlert,
    WaitlistEntry, ExternalReferral
)

def create_sample_data():
    print("Creating sample data...")
    
    # Create admin / management user
    admin_user, created = User.objects.get_or_create(
        username='admin',
        defaults={
            'email': 'admin@campuscare.spu.ac.za',
            'first_name': 'Clinic',
            'last_name': 'Manager',
            'is_staff': True,
            'is_superuser': True
        }
    )
    admin_user.set_password('admin123')
    admin_user.save()

    Staff.objects.get_or_create(
        user=admin_user,
        defaults={'staff_id': 'MGT001', 'role': 'management', 'phone': '0531234560'}
    )
    print("Admin/Management user ready (username: admin, password: admin123)")
    
    # Create clinical staff
    staff_profiles = [
        {'username': 'dr_sarah', 'first_name': 'Sarah', 'last_name': 'Connor', 'email': 'sarah.connor@spu.ac.za', 'staff_id': 'DOC001', 'role': 'doctor'},
        {'username': 'nurse_mary', 'first_name': 'Mary', 'last_name': 'Mokoena', 'email': 'mary.mokoena@spu.ac.za', 'staff_id': 'NRS001', 'role': 'nurse'},
        {'username': 'counsel_david', 'first_name': 'David', 'last_name': 'Khumalo', 'email': 'david.khumalo@spu.ac.za', 'staff_id': 'CNS001', 'role': 'counsellor'},
        {'username': 'social_thabo', 'first_name': 'Thabo', 'last_name': 'Molefe', 'email': 'thabo.molefe@spu.ac.za', 'staff_id': 'SW001', 'role': 'social_worker'},
    ]

    staff_objs = []
    for sp in staff_profiles:
        u, _ = User.objects.get_or_create(
            username=sp['username'],
            defaults={'first_name': sp['first_name'], 'last_name': sp['last_name'], 'email': sp['email'], 'is_staff': True}
        )
        u.set_password('password123')
        u.save()

        st, _ = Staff.objects.get_or_create(
            user=u,
            defaults={'staff_id': sp['staff_id'], 'role': sp['role'], 'phone': '0538901234'}
        )
        staff_objs.append(st)

        # Set up weekly availability (Mon - Fri: 08:00 - 17:00)
        for day in range(5):
            StaffAvailability.objects.get_or_create(
                staff=st,
                day_of_week=day,
                defaults={'start_time': time(8, 0), 'end_time': time(17, 0), 'is_available': True}
            )
            StaffLunchBreak.objects.get_or_create(
                staff=st,
                day_of_week=day,
                defaults={
                    'start_time': time(13, 0),
                    'end_time': time(14, 0),
                    'is_active': True,
                    'is_emergency_override': False,
                }
            )
        print(f"Clinical Staff {u.get_full_name()} ({sp['role']}) created with schedule and fixed lunch (13:00-14:00).")

    # Create sample students
    students_data = [
        {'username': 'john_doe', 'first_name': 'John', 'last_name': 'Doe', 'email': 'john@campus.spu.ac.za', 'student_number': '20240001', 'faculty': 'Natural & Applied Sciences', 'year': 2, 'blood': 'O+'},
        {'username': 'jane_smith', 'first_name': 'Jane', 'last_name': 'Smith', 'email': 'jane@campus.spu.ac.za', 'student_number': '20240002', 'faculty': 'Humanities', 'year': 3, 'blood': 'A-'},
        {'username': 'mike_johnson', 'first_name': 'Mike', 'last_name': 'Johnson', 'email': 'mike@campus.spu.ac.za', 'student_number': '20240003', 'faculty': 'Education', 'year': 1, 'blood': 'B+'},
        {'username': 'lerato_molefe', 'first_name': 'Lerato', 'last_name': 'Molefe', 'email': 'lerato@campus.spu.ac.za', 'student_number': '20240004', 'faculty': 'Economic & Management Sciences', 'year': 4, 'blood': 'AB+'},
    ]
    
    students = []
    for data in students_data:
        user, _ = User.objects.get_or_create(
            username=data['username'],
            defaults={'first_name': data['first_name'], 'last_name': data['last_name'], 'email': data['email']}
        )
        user.set_password('password123')
        user.save()
        
        student, _ = Student.objects.get_or_create(
            user=user,
            defaults={
                'student_number': data['student_number'],
                'phone': '0721234567',
                'faculty': data['faculty'],
                'year_of_study': data['year'],
                'blood_type': data['blood'],
                'allergies': 'Penicillin' if data['username'] == 'jane_smith' else 'None',
                'emergency_contact_name': 'Parent / Guardian',
                'emergency_contact_phone': '0829876543'
            }
        )
        students.append(student)
        print(f"Student {student.user.get_full_name()} created.")
    
    # Create sample appointments for today and upcoming days
    today = date.today()
    appointment_data = [
        # Emergency case today
        {'student': students[0], 'staff': staff_objs[0], 'category': 'general', 'urgency': 'emergency', 
         'date': today, 'time': time(9, 0), 'symptoms': 'Acute crushing chest tightness and shortness of breath', 'status': 'confirmed'},
        # Urgent case today
        {'student': students[1], 'staff': staff_objs[0], 'category': 'injury', 'urgency': 'urgent', 
         'date': today, 'time': time(9, 30), 'symptoms': 'Severe ankle swelling and inability to bear weight after fall', 'status': 'confirmed'},
        # Routine case today
        {'student': students[2], 'staff': staff_objs[0], 'category': 'general', 'urgency': 'routine', 
         'date': today, 'time': time(10, 0), 'symptoms': 'Mild sore throat and seasonal allergy review', 'status': 'confirmed'},
        # Mental Health Consultation
        {'student': students[3], 'staff': staff_objs[2], 'category': 'mental', 'urgency': 'urgent', 
         'date': today, 'time': time(11, 0), 'symptoms': 'Severe exam anxiety panic attacks', 'status': 'confirmed'},
        # Completed consultation with clinical notes
        {'student': students[0], 'staff': staff_objs[1], 'category': 'general', 'urgency': 'routine', 
         'date': today - timedelta(days=2), 'time': time(14, 0), 'symptoms': 'Flu and headache', 'status': 'completed',
         'diagnosis': 'Acute Viral Pharyngitis', 'treatment_plan': 'Paracetamol 500mg, bed rest, hydration', 'clinical_notes': 'Vitals stable. Throat mildly erythematous.'},
    ]
    
    for data in appointment_data:
        appt, created = Appointment.objects.get_or_create(
            appointment_date=data['date'],
            appointment_time=data['time'],
            assigned_staff=data['staff'],
            defaults={
                'student': data['student'],
                'category': data['category'],
                'urgency': data['urgency'],
                'symptoms': data['symptoms'],
                'status': data['status'],
                'diagnosis': data.get('diagnosis', ''),
                'treatment_plan': data.get('treatment_plan', ''),
                'clinical_notes': data.get('clinical_notes', '')
            }
        )
        if created:
            print(f"Appointment created: {appt.category} ({appt.urgency}) on {appt.appointment_date} at {appt.appointment_time}")
    
    # Create sample anonymous appointment for sensitive mental health consultation
    Appointment.objects.get_or_create(
        appointment_date=today,
        appointment_time=time(14, 30),
        assigned_staff=staff_objs[2],
        defaults={
            'student': None,  # Structurally disassociated
            'is_anonymous': True,
            'anonymous_code': 'ANON-ME-88419B',
            'category': 'mental',
            'urgency': 'urgent',
            'symptoms': 'Confidential counselling for emotional trauma and depression',
            'status': 'confirmed'
        }
    )
    print("Anonymous mental health consultation created with zero PII.")

    # Create waitlist entry
    WaitlistEntry.objects.get_or_create(
        preferred_date=today,
        preferred_staff=staff_objs[0],
        category='general',
        defaults={
            'student': students[3],
            'urgency': 'urgent',
            'symptoms': 'Persistent high fever 39.2C with chills',
            'status': 'waiting'
        }
    )
    print("Waitlist entry created.")

    # Create external referral
    ExternalReferral.objects.get_or_create(
        student=students[3],
        service_name='Kimberley Hospital Complex - Crisis Psychiatry Unit',
        defaults={
            'referred_by': staff_objs[2],
            'service_type': 'Psychiatry & Inpatient Crisis Support',
            'urgency': 'urgent',
            'reason': 'Evaluation for acute panic disorder requiring specialized clinical intervention',
            'clinical_summary': 'Initial counselling on campus revealed recurrent debilitating panic attacks.',
            'status': 'transmitted'
        }
    )
    print("External referral created.")

    # Create notifications
    for student in students:
        Notification.objects.get_or_create(
            user=student.user,
            title='Welcome to Campus Care',
            defaults={
                'message': f'Welcome {student.user.first_name}! Your student wellness portal account is active.'
            }
        )
    
    # Create health alerts
    alerts_data = [
        {'title': 'Flu Season Vaccination', 'message': 'Seasonal flu vaccines are now available at Central Campus Clinic.', 'severity': 'warning'},
        {'title': 'Mental Wellness Workshop', 'message': 'Free stress & mindfulness workshop this Friday at 14:00 in Student Centre.', 'severity': 'info'},
        {'title': 'Mpox & COVID Vigilance', 'message': 'Please practice frequent hand hygiene. Masks available at clinic reception.', 'severity': 'danger'},
    ]
    
    for data in alerts_data:
        HealthAlert.objects.get_or_create(
            title=data['title'],
            defaults={'message': data['message'], 'severity': data['severity']}
        )
    
    print("\n" + "="*60)
    print("ALL SAMPLE CLINICAL & MANAGEMENT DATA CREATED SUCCESSFULLY!")
    print("="*60)
    print("\nLogin Credentials:")
    print("-" * 40)
    print("Clinic Management / Administrator:")
    print("  Username: admin, Password: admin123")
    print("\nClinical Staff (Doctor, Nurse, Counsellor):")
    print("  Username: dr_sarah, Password: password123 (Doctor)")
    print("  Username: nurse_mary, Password: password123 (Nurse)")
    print("  Username: counsel_david, Password: password123 (Counsellor)")
    print("\nStudent Accounts:")
    print("  Username: john_doe, Password: password123")
    print("  Username: jane_smith, Password: password123")
    print("  Username: mike_johnson, Password: password123")
    print("  Username: lerato_molefe, Password: password123")
    print("="*60)

if __name__ == "__main__":
    create_sample_data()