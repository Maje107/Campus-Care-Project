import os
from io import BytesIO
from datetime import datetime, date
from django.conf import settings

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def generate_clinic_management_pdf(report_title, start_date, end_date, metrics, user_name="Automated System"):
    """
    Generates a professional, hospital-grade PDF report for weekly/monthly clinic analytics.
    Returns BytesIO buffer.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=36,
        leftMargin=36,
        topMargin=36,
        bottomMargin=36
    )

    styles = getSampleStyleSheet()
    
    # Custom Styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=18,
        leading=22,
        textColor=colors.HexColor("#0000003D")  # SPU Dark Red
    )

    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#0000003D")
    )

    section_header = ParagraphStyle(
        'SectionHeader',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#0000003D"),
        spaceBefore=10,
        spaceAfter=6
    )

    cell_bold = ParagraphStyle('CellBold', parent=styles['Normal'], fontName='Helvetica-Bold', fontSize=9, leading=12)
    cell_regular = ParagraphStyle('CellReg', parent=styles['Normal'], fontName='Helvetica', fontSize=9, leading=12)
    cell_right = ParagraphStyle('CellRight', parent=styles['Normal'], fontName='Helvetica', fontSize=9, leading=12, alignment=2)

    story = []

    # 1. Header Banner
    story.append(Paragraph("SOL PLAATJE UNIVERSITY — STUDENT WELLNESS SERVICES", subtitle_style))
    story.append(Paragraph(f"Campus Care Clinic: {report_title}", title_style))
    story.append(Spacer(1, 4))
    
    meta_text = (
        f"<b>Reporting Window:</b> {start_date.strftime('%d %B %Y')} to {end_date.strftime('%d %B %Y')} &nbsp;|&nbsp; "
        f"<b>Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M')} &nbsp;|&nbsp; "
        f"<b>Author:</b> {user_name}"
    )
    story.append(Paragraph(meta_text, subtitle_style))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#9B1C1C'), spaceAfter=14))

    # 2. Executive KPI Overview Table
    story.append(Paragraph("Executive Performance Summary", section_header))

    kpi_data = [
        [
            Paragraph("Total Scheduled Bookings", cell_bold),
            Paragraph(str(metrics.get('total_appointments', 0)), cell_right),
            Paragraph("Completed Consultations", cell_bold),
            Paragraph(str(metrics.get('completed_count', 0)), cell_right),
        ],
        [
            Paragraph("No-Show Count", cell_bold),
            Paragraph(str(metrics.get('no_show_count', 0)), cell_right),
            Paragraph("No-Show Rate", cell_bold),
            Paragraph(f"{metrics.get('no_show_rate', 0.0):.1f}%", cell_right),
        ],
        [
            Paragraph("Cancelled Sessions", cell_bold),
            Paragraph(str(metrics.get('cancelled_count', 0)), cell_right),
            Paragraph("Average Patient Wait Time", cell_bold),
            Paragraph(f"{metrics.get('avg_wait_minutes', 0.0):.1f} mins", cell_right),
        ],
        [
            Paragraph("Emergency & Urgent Cases", cell_bold),
            Paragraph(str(metrics.get('acute_cases_count', 0)), cell_right),
            Paragraph("External Specialist Referrals", cell_bold),
            Paragraph(str(metrics.get('referrals_count', 0)), cell_right),
        ]
    ]

    t_kpi = Table(kpi_data, colWidths=[150, 110, 150, 110])
    t_kpi.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F9FAFB')),
        ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#E5E7EB')),
        ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E5E7EB')),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(t_kpi)
    story.append(Spacer(1, 14))

    # 3. Case Distribution Breakdown
    story.append(Paragraph("Consultation Volume by Health Category", section_header))
    cat_rows = [
        [
            Paragraph("Health Category", cell_bold),
            Paragraph("Total Bookings", cell_bold),
            Paragraph("% of Volume", cell_bold),
            Paragraph("Completed", cell_bold),
            Paragraph("Urgent / Emergency", cell_bold),
        ]
    ]

    for cat in metrics.get('category_distribution', []):
        cat_rows.append([
            Paragraph(cat.get('category', 'Unknown'), cell_regular),
            Paragraph(str(cat.get('total', 0)), cell_regular),
            Paragraph(f"{cat.get('pct', 0.0):.1f}%", cell_regular),
            Paragraph(str(cat.get('completed', 0)), cell_regular),
            Paragraph(str(cat.get('urgent_count', 0)), cell_regular),
        ])

    t_cat = Table(cat_rows, colWidths=[170, 90, 80, 80, 100])
    t_cat.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F9FAFB')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#D1D5DB')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F9FAFB')]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(t_cat)
    story.append(Spacer(1, 14))

    # 4. Demographic & Faculty Utilization
    story.append(Paragraph("Student Demographic & Faculty Utilization", section_header))
    fac_rows = [
        [
            Paragraph("Faculty / Demographic Group", cell_bold),
            Paragraph("Total Consultations", cell_bold),
            Paragraph("Percentage (%)", cell_bold)
        ]
    ]
    for fac in metrics.get('demographics', []):
        fac_rows.append([
            Paragraph(fac.get('name', 'General Student Body'), cell_regular),
            Paragraph(str(fac.get('count', 0)), cell_regular),
            Paragraph(f"{fac.get('pct', 0.0):.1f}%", cell_regular),
        ])

    t_fac = Table(fac_rows, colWidths=[260, 130, 130])
    t_fac.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F9FAFB')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#D1D5DB')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F9FAFB')]),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(t_fac)
    story.append(Spacer(1, 16))

    # 5. Clinic Accreditation and Governance Footer
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#D1D5DB'), spaceAfter=8))
    footer_text = (
        "CONFIDENTIAL MEDICAL GOVERNANCE REPORT — For Authorized University Management Use Only.<br/>"
        "Sol Plaatje University Student Wellness Centre, Central Campus, Kimberley, Northern Cape.<br/>"
        "Complies with National Health Act (Act No. 61 of 2003) & POPIA patient privacy standards."
    )
    story.append(Paragraph(footer_text, ParagraphStyle('Footer', parent=styles['Normal'], fontName='Helvetica', fontSize=7, leading=10, textColor=colors.HexColor('#9CA3AF'))))

    doc.build(story)
    buffer.seek(0)
    return buffer
