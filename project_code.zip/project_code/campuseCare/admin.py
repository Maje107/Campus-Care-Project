from django.contrib import admin
from .models import (
    Student, Staff, Appointment, Notification,
    HealthAlert, SMSLog, WaitlistEntry, MedicalRecord, PasswordResetOTP
)


@admin.register(SMSLog)
class SMSLogAdmin(admin.ModelAdmin):
    list_display = ('recipient_phone', 'message_type', 'status', 'created_at', 'recipient_user')
    list_filter = ('status', 'message_type', 'created_at')
    search_fields = ('recipient_phone', 'message', 'recipient_user__username', 'recipient_user__email')
    readonly_fields = ('created_at',)


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('user', 'student_number', 'phone', 'faculty', 'year_of_study')
    search_fields = ('student_number', 'user__first_name', 'user__last_name', 'phone')


@admin.register(Staff)
class StaffAdmin(admin.ModelAdmin):
    list_display = ('user', 'staff_id', 'role', 'phone')
    list_filter = ('role',)
    search_fields = ('staff_id', 'user__first_name', 'user__last_name', 'phone')


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'display_patient_name', 'category', 'urgency', 'appointment_date', 'appointment_time', 'status')
    list_filter = ('status', 'category', 'urgency', 'appointment_date')
    search_fields = ('student__student_number', 'student__user__first_name', 'anonymous_code')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'title', 'is_read', 'created_at')
    list_filter = ('is_read', 'created_at')
