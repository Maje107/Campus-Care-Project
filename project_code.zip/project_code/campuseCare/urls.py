from django.urls import path
from . import views

urlpatterns = [
    # Authentication & Onboarding
    path('', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('register-staff/', views.register_staff, name='register_staff'),
    path('logout/', views.logout_view, name='logout'),

    # Forgot Password via SMS OTP
    path('password/forgot/', views.forgot_password, name='forgot_password'),
    path('password/verify-otp/', views.verify_reset_otp, name='verify_reset_otp'),
    path('password/reset/', views.reset_password, name='reset_password'),

    # Student Portal & Booking
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('book/', views.book_appointment, name='book_appointment'),
    path('my-appointments/', views.my_appointments, name='my_appointments'),
    path('my-health-history/', views.my_health_history, name='my_health_history'),
    path('records/', views.my_records, name='my_records'),
    path('records/<int:pk>/download/', views.download_record, name='download_record'),
    path('staff/<int:staff_id>/calendar/', views.staff_calendar_view, name='staff_calendar_view'),
    path('waitlist/join/', views.join_waitlist, name='join_waitlist'),

    # Dynamic Slot Lookup API
    path('api/slots/available/', views.get_available_slots_api, name='get_available_slots_api'),

    # Direct Actionable Reminder & Anonymous Consultation Endpoints
    path('appointment/action/<uuid:token>/', views.appointment_action_view, name='appointment_action_view'),
    path('appointment/anonymous/<uuid:token>/', views.anonymous_booking_view, name='anonymous_booking_view'),

    # Appointment Details & Student Actions
    path('appointment/<int:pk>/', views.appointment_detail, name='appointment_detail'),
    path('appointment/<int:pk>/cancel/', views.cancel_appointment, name='cancel_appointment'),

    # Secure Staff Dashboard & Scheduling
    path('staff/dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('staff/calendar/', views.staff_weekly_calendar, name='staff_weekly_calendar'),
    path('staff/availability/', views.manage_availability, name='manage_availability'),
    path('staff/emergency-slots/', views.manage_emergency_slots, name='manage_emergency_slots'),
    path('staff/records/', views.staff_view_records, name='staff_view_records'),

    # Staff Real-Time Live Queue API & Inline Actions
    path('api/staff/queue-live/', views.staff_queue_live_api, name='staff_queue_live_api'),
    path('api/appointment/<int:pk>/inline-complete/', views.inline_complete_appointment, name='inline_complete_appointment'),
    path('api/appointment/<int:pk>/inline-referral/', views.inline_external_referral, name='inline_external_referral'),
    path('api/appointment/<int:pk>/inline-no-show/', views.inline_mark_no_show, name='inline_mark_no_show'),
    path('api/student/<int:student_id>/inline-update-record/', views.inline_update_student_record, name='inline_update_student_record'),

    # Standard Staff Consultation Flow
    path('all-appointments/', views.all_appointments, name='all_appointments'),
    path('appointment/<int:pk>/approve/', views.approve_appointment, name='approve_appointment'),
    path('appointment/<int:pk>/decline/', views.decline_appointment, name='decline_appointment'),
    path('appointment/<int:pk>/complete/', views.complete_appointment, name='complete_appointment'),
    path('appointment/<int:pk>/cancel-staff/', views.cancel_appointment_staff, name='cancel_appointment_staff'),
    path('appointment/<int:pk>/generate-report/', views.generate_report, name='generate_report'),
    path('report/<int:pk>/download/', views.download_report, name='download_report'),

    # Management Analytics, Anomaly Detection & PDF Reports
    path('management/analytics/', views.management_analytics_dashboard, name='management_analytics_dashboard'),
    path('management/report/pdf/', views.download_management_pdf_report, name='download_management_pdf_report'),
    path('management/anomaly/<int:pk>/acknowledge/', views.acknowledge_anomaly_alert, name='acknowledge_anomaly_alert'),

    # User Profile & Alerts
    path('profile/', views.profile, name='profile'),
    path('profile/update/', views.update_profile, name='update_profile'),
    path('notifications/', views.notifications, name='notifications'),
    path('manage-alerts/', views.manage_alerts, name='manage_alerts'),

    # Student Health Alerts, Popups & Live Data Integrations
    path('health-alerts/', views.health_alerts, name='health_alerts'),
    path('health-alerts/action/', views.health_alert_action, name='health_alert_action'),
    path('api/health-alerts/refresh/', views.refresh_live_health_data_api, name='refresh_live_health_data_api'),

    # Bulk SMS Diagnostic & Testing API
    path('api/sms/test-send/', views.test_send_sms_api, name='test_send_sms_api'),

    # Send SMS directly to student from an appointment
    path('appointment/<int:pk>/send-sms/', views.send_sms_from_appointment, name='send_sms_from_appointment'),
]
